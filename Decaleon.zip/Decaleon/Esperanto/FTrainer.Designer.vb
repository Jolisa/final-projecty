﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FTrainer
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBoxSelection = New System.Windows.Forms.GroupBox()
        Me.ButtonApply = New System.Windows.Forms.Button()
        Me.GroupBoxLanguages = New System.Windows.Forms.GroupBox()
        Me.ComboBoxToLang = New System.Windows.Forms.ComboBox()
        Me.ComboBoxFromLang = New System.Windows.Forms.ComboBox()
        Me.LabelToLang = New System.Windows.Forms.Label()
        Me.LabelFromLang = New System.Windows.Forms.Label()
        Me.GroupBoxResults = New System.Windows.Forms.GroupBox()
        Me.LabelScore = New System.Windows.Forms.Label()
        Me.LabelDone = New System.Windows.Forms.Label()
        Me.LabelSelected = New System.Windows.Forms.Label()
        Me.LabelStaticScore = New System.Windows.Forms.Label()
        Me.LabelStaticDone = New System.Windows.Forms.Label()
        Me.LabelStaticSelected = New System.Windows.Forms.Label()
        Me.GroupBoxNiveaus = New System.Windows.Forms.GroupBox()
        Me.CheckBoxB2 = New System.Windows.Forms.CheckBox()
        Me.CheckBoxB1 = New System.Windows.Forms.CheckBox()
        Me.CheckBoxA2 = New System.Windows.Forms.CheckBox()
        Me.CheckBoxA1 = New System.Windows.Forms.CheckBox()
        Me.GroupBoxChoice = New System.Windows.Forms.GroupBox()
        Me.RadioButtonUseChoice = New System.Windows.Forms.RadioButton()
        Me.RadioButtonAppendChoice = New System.Windows.Forms.RadioButton()
        Me.RadioButtonNewChoice = New System.Windows.Forms.RadioButton()
        Me.GroupBoxTraining = New System.Windows.Forms.GroupBox()
        Me.GroupBoxUnit = New System.Windows.Forms.GroupBox()
        Me.ButtonCorrect = New System.Windows.Forms.Button()
        Me.LabelWordTimestamp = New System.Windows.Forms.Label()
        Me.LabelWordState = New System.Windows.Forms.Label()
        Me.RichTextBoxWordInfo = New System.Windows.Forms.RichTextBox()
        Me.LabelWordToCheck5 = New System.Windows.Forms.Label()
        Me.LabelWordToCheck4 = New System.Windows.Forms.Label()
        Me.LabelWordToCheck3 = New System.Windows.Forms.Label()
        Me.LabelWordToCheck2 = New System.Windows.Forms.Label()
        Me.LabelWordToCheck1 = New System.Windows.Forms.Label()
        Me.LabelWordGiven = New System.Windows.Forms.Label()
        Me.ButtonGoOn = New System.Windows.Forms.Button()
        Me.LabelHint = New System.Windows.Forms.Label()
        Me.GroupBoxModus = New System.Windows.Forms.GroupBox()
        Me.CheckBoxAutomatic = New System.Windows.Forms.CheckBox()
        Me.LabelNumWords = New System.Windows.Forms.Label()
        Me.ButtonStartUnit = New System.Windows.Forms.Button()
        Me.ComboBoxNumberOfTimes = New System.Windows.Forms.ComboBox()
        Me.ComboBoxNumberOfWords = New System.Windows.Forms.ComboBox()
        Me.LabelNumberOfTimes = New System.Windows.Forms.Label()
        Me.LabelNumberOfWords = New System.Windows.Forms.Label()
        Me.RadioButtonMixed = New System.Windows.Forms.RadioButton()
        Me.RadioButtonOldWords = New System.Windows.Forms.RadioButton()
        Me.RadioButtonNewWords = New System.Windows.Forms.RadioButton()
        Me.ButtonOK = New System.Windows.Forms.Button()
        Me.ButtonStart = New System.Windows.Forms.Button()
        Me.CheckBoxC1 = New System.Windows.Forms.CheckBox()
        Me.CheckBoxC2 = New System.Windows.Forms.CheckBox()
        Me.CheckBoxEX = New System.Windows.Forms.CheckBox()
        Me.GroupBoxSelection.SuspendLayout()
        Me.GroupBoxLanguages.SuspendLayout()
        Me.GroupBoxResults.SuspendLayout()
        Me.GroupBoxNiveaus.SuspendLayout()
        Me.GroupBoxChoice.SuspendLayout()
        Me.GroupBoxTraining.SuspendLayout()
        Me.GroupBoxUnit.SuspendLayout()
        Me.GroupBoxModus.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBoxSelection
        '
        Me.GroupBoxSelection.Controls.Add(Me.ButtonApply)
        Me.GroupBoxSelection.Controls.Add(Me.GroupBoxLanguages)
        Me.GroupBoxSelection.Controls.Add(Me.GroupBoxResults)
        Me.GroupBoxSelection.Controls.Add(Me.GroupBoxNiveaus)
        Me.GroupBoxSelection.Controls.Add(Me.GroupBoxChoice)
        Me.GroupBoxSelection.Location = New System.Drawing.Point(20, 23)
        Me.GroupBoxSelection.Name = "GroupBoxSelection"
        Me.GroupBoxSelection.Size = New System.Drawing.Size(181, 515)
        Me.GroupBoxSelection.TabIndex = 0
        Me.GroupBoxSelection.TabStop = False
        Me.GroupBoxSelection.Text = "Auswahl"
        '
        'ButtonApply
        '
        Me.ButtonApply.Location = New System.Drawing.Point(38, 360)
        Me.ButtonApply.Name = "ButtonApply"
        Me.ButtonApply.Size = New System.Drawing.Size(103, 27)
        Me.ButtonApply.TabIndex = 2
        Me.ButtonApply.Text = "Verwenden"
        Me.ButtonApply.UseVisualStyleBackColor = True
        '
        'GroupBoxLanguages
        '
        Me.GroupBoxLanguages.Controls.Add(Me.ComboBoxToLang)
        Me.GroupBoxLanguages.Controls.Add(Me.ComboBoxFromLang)
        Me.GroupBoxLanguages.Controls.Add(Me.LabelToLang)
        Me.GroupBoxLanguages.Controls.Add(Me.LabelFromLang)
        Me.GroupBoxLanguages.Location = New System.Drawing.Point(14, 244)
        Me.GroupBoxLanguages.Name = "GroupBoxLanguages"
        Me.GroupBoxLanguages.Size = New System.Drawing.Size(147, 110)
        Me.GroupBoxLanguages.TabIndex = 2
        Me.GroupBoxLanguages.TabStop = False
        Me.GroupBoxLanguages.Text = "Sprachen"
        '
        'ComboBoxToLang
        '
        Me.ComboBoxToLang.FormattingEnabled = True
        Me.ComboBoxToLang.Location = New System.Drawing.Point(15, 76)
        Me.ComboBoxToLang.Name = "ComboBoxToLang"
        Me.ComboBoxToLang.Size = New System.Drawing.Size(121, 21)
        Me.ComboBoxToLang.TabIndex = 3
        '
        'ComboBoxFromLang
        '
        Me.ComboBoxFromLang.FormattingEnabled = True
        Me.ComboBoxFromLang.Location = New System.Drawing.Point(15, 36)
        Me.ComboBoxFromLang.Name = "ComboBoxFromLang"
        Me.ComboBoxFromLang.Size = New System.Drawing.Size(121, 21)
        Me.ComboBoxFromLang.TabIndex = 2
        '
        'LabelToLang
        '
        Me.LabelToLang.AutoSize = True
        Me.LabelToLang.Location = New System.Drawing.Point(12, 60)
        Me.LabelToLang.Name = "LabelToLang"
        Me.LabelToLang.Size = New System.Drawing.Size(31, 13)
        Me.LabelToLang.TabIndex = 1
        Me.LabelToLang.Text = "nach"
        '
        'LabelFromLang
        '
        Me.LabelFromLang.AutoSize = True
        Me.LabelFromLang.Location = New System.Drawing.Point(12, 20)
        Me.LabelFromLang.Name = "LabelFromLang"
        Me.LabelFromLang.Size = New System.Drawing.Size(25, 13)
        Me.LabelFromLang.TabIndex = 0
        Me.LabelFromLang.Text = "von"
        '
        'GroupBoxResults
        '
        Me.GroupBoxResults.Controls.Add(Me.LabelScore)
        Me.GroupBoxResults.Controls.Add(Me.LabelDone)
        Me.GroupBoxResults.Controls.Add(Me.LabelSelected)
        Me.GroupBoxResults.Controls.Add(Me.LabelStaticScore)
        Me.GroupBoxResults.Controls.Add(Me.LabelStaticDone)
        Me.GroupBoxResults.Controls.Add(Me.LabelStaticSelected)
        Me.GroupBoxResults.Location = New System.Drawing.Point(14, 403)
        Me.GroupBoxResults.Name = "GroupBoxResults"
        Me.GroupBoxResults.Size = New System.Drawing.Size(147, 100)
        Me.GroupBoxResults.TabIndex = 3
        Me.GroupBoxResults.TabStop = False
        Me.GroupBoxResults.Text = "Ergebnisse"
        '
        'LabelScore
        '
        Me.LabelScore.AutoSize = True
        Me.LabelScore.BackColor = System.Drawing.SystemColors.Info
        Me.LabelScore.Location = New System.Drawing.Point(73, 73)
        Me.LabelScore.Name = "LabelScore"
        Me.LabelScore.Size = New System.Drawing.Size(13, 13)
        Me.LabelScore.TabIndex = 5
        Me.LabelScore.Text = "0"
        Me.LabelScore.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LabelDone
        '
        Me.LabelDone.AutoSize = True
        Me.LabelDone.BackColor = System.Drawing.SystemColors.Info
        Me.LabelDone.Location = New System.Drawing.Point(73, 49)
        Me.LabelDone.Name = "LabelDone"
        Me.LabelDone.Size = New System.Drawing.Size(13, 13)
        Me.LabelDone.TabIndex = 4
        Me.LabelDone.Text = "0"
        Me.LabelDone.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LabelSelected
        '
        Me.LabelSelected.AutoSize = True
        Me.LabelSelected.BackColor = System.Drawing.SystemColors.Info
        Me.LabelSelected.Location = New System.Drawing.Point(73, 25)
        Me.LabelSelected.Name = "LabelSelected"
        Me.LabelSelected.Size = New System.Drawing.Size(13, 13)
        Me.LabelSelected.TabIndex = 3
        Me.LabelSelected.Text = "0"
        Me.LabelSelected.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LabelStaticScore
        '
        Me.LabelStaticScore.AutoSize = True
        Me.LabelStaticScore.BackColor = System.Drawing.Color.SandyBrown
        Me.LabelStaticScore.Location = New System.Drawing.Point(10, 73)
        Me.LabelStaticScore.Name = "LabelStaticScore"
        Me.LabelStaticScore.Size = New System.Drawing.Size(58, 13)
        Me.LabelStaticScore.TabIndex = 2
        Me.LabelStaticScore.Text = "Bewertung"
        '
        'LabelStaticDone
        '
        Me.LabelStaticDone.AutoSize = True
        Me.LabelStaticDone.Location = New System.Drawing.Point(10, 49)
        Me.LabelStaticDone.Name = "LabelStaticDone"
        Me.LabelStaticDone.Size = New System.Drawing.Size(54, 13)
        Me.LabelStaticDone.TabIndex = 1
        Me.LabelStaticDone.Text = "bearbeitet"
        '
        'LabelStaticSelected
        '
        Me.LabelStaticSelected.AutoSize = True
        Me.LabelStaticSelected.Location = New System.Drawing.Point(10, 25)
        Me.LabelStaticSelected.Name = "LabelStaticSelected"
        Me.LabelStaticSelected.Size = New System.Drawing.Size(44, 13)
        Me.LabelStaticSelected.TabIndex = 0
        Me.LabelStaticSelected.Text = "gewählt"
        '
        'GroupBoxNiveaus
        '
        Me.GroupBoxNiveaus.Controls.Add(Me.CheckBoxEX)
        Me.GroupBoxNiveaus.Controls.Add(Me.CheckBoxC2)
        Me.GroupBoxNiveaus.Controls.Add(Me.CheckBoxC1)
        Me.GroupBoxNiveaus.Controls.Add(Me.CheckBoxB2)
        Me.GroupBoxNiveaus.Controls.Add(Me.CheckBoxB1)
        Me.GroupBoxNiveaus.Controls.Add(Me.CheckBoxA2)
        Me.GroupBoxNiveaus.Controls.Add(Me.CheckBoxA1)
        Me.GroupBoxNiveaus.Location = New System.Drawing.Point(14, 117)
        Me.GroupBoxNiveaus.Name = "GroupBoxNiveaus"
        Me.GroupBoxNiveaus.Size = New System.Drawing.Size(149, 121)
        Me.GroupBoxNiveaus.TabIndex = 1
        Me.GroupBoxNiveaus.TabStop = False
        Me.GroupBoxNiveaus.Text = "Niveaus"
        '
        'CheckBoxB2
        '
        Me.CheckBoxB2.AutoSize = True
        Me.CheckBoxB2.Location = New System.Drawing.Point(14, 92)
        Me.CheckBoxB2.Name = "CheckBoxB2"
        Me.CheckBoxB2.Size = New System.Drawing.Size(39, 17)
        Me.CheckBoxB2.TabIndex = 3
        Me.CheckBoxB2.Text = "B2"
        Me.CheckBoxB2.UseVisualStyleBackColor = True
        '
        'CheckBoxB1
        '
        Me.CheckBoxB1.AutoSize = True
        Me.CheckBoxB1.Location = New System.Drawing.Point(14, 69)
        Me.CheckBoxB1.Name = "CheckBoxB1"
        Me.CheckBoxB1.Size = New System.Drawing.Size(39, 17)
        Me.CheckBoxB1.TabIndex = 2
        Me.CheckBoxB1.Text = "B1"
        Me.CheckBoxB1.UseVisualStyleBackColor = True
        '
        'CheckBoxA2
        '
        Me.CheckBoxA2.AutoSize = True
        Me.CheckBoxA2.Location = New System.Drawing.Point(14, 46)
        Me.CheckBoxA2.Name = "CheckBoxA2"
        Me.CheckBoxA2.Size = New System.Drawing.Size(39, 17)
        Me.CheckBoxA2.TabIndex = 1
        Me.CheckBoxA2.Text = "A2"
        Me.CheckBoxA2.UseVisualStyleBackColor = True
        '
        'CheckBoxA1
        '
        Me.CheckBoxA1.AutoSize = True
        Me.CheckBoxA1.Location = New System.Drawing.Point(14, 23)
        Me.CheckBoxA1.Name = "CheckBoxA1"
        Me.CheckBoxA1.Size = New System.Drawing.Size(39, 17)
        Me.CheckBoxA1.TabIndex = 0
        Me.CheckBoxA1.Text = "A1"
        Me.CheckBoxA1.UseVisualStyleBackColor = True
        '
        'GroupBoxChoice
        '
        Me.GroupBoxChoice.Controls.Add(Me.RadioButtonUseChoice)
        Me.GroupBoxChoice.Controls.Add(Me.RadioButtonAppendChoice)
        Me.GroupBoxChoice.Controls.Add(Me.RadioButtonNewChoice)
        Me.GroupBoxChoice.Location = New System.Drawing.Point(15, 19)
        Me.GroupBoxChoice.Name = "GroupBoxChoice"
        Me.GroupBoxChoice.Size = New System.Drawing.Size(149, 92)
        Me.GroupBoxChoice.TabIndex = 0
        Me.GroupBoxChoice.TabStop = False
        Me.GroupBoxChoice.Text = "Auswahl"
        '
        'RadioButtonUseChoice
        '
        Me.RadioButtonUseChoice.AutoSize = True
        Me.RadioButtonUseChoice.Location = New System.Drawing.Point(14, 65)
        Me.RadioButtonUseChoice.Name = "RadioButtonUseChoice"
        Me.RadioButtonUseChoice.Size = New System.Drawing.Size(121, 17)
        Me.RadioButtonUseChoice.TabIndex = 2
        Me.RadioButtonUseChoice.TabStop = True
        Me.RadioButtonUseChoice.Text = "Auswahl verwenden"
        Me.RadioButtonUseChoice.UseVisualStyleBackColor = True
        '
        'RadioButtonAppendChoice
        '
        Me.RadioButtonAppendChoice.AutoSize = True
        Me.RadioButtonAppendChoice.Location = New System.Drawing.Point(14, 42)
        Me.RadioButtonAppendChoice.Name = "RadioButtonAppendChoice"
        Me.RadioButtonAppendChoice.Size = New System.Drawing.Size(112, 17)
        Me.RadioButtonAppendChoice.TabIndex = 1
        Me.RadioButtonAppendChoice.TabStop = True
        Me.RadioButtonAppendChoice.Text = "Auswahl ergänzen"
        Me.RadioButtonAppendChoice.UseVisualStyleBackColor = True
        '
        'RadioButtonNewChoice
        '
        Me.RadioButtonNewChoice.AutoSize = True
        Me.RadioButtonNewChoice.Location = New System.Drawing.Point(14, 19)
        Me.RadioButtonNewChoice.Name = "RadioButtonNewChoice"
        Me.RadioButtonNewChoice.Size = New System.Drawing.Size(94, 17)
        Me.RadioButtonNewChoice.TabIndex = 0
        Me.RadioButtonNewChoice.TabStop = True
        Me.RadioButtonNewChoice.Text = "Neue Auswahl"
        Me.RadioButtonNewChoice.UseVisualStyleBackColor = True
        '
        'GroupBoxTraining
        '
        Me.GroupBoxTraining.Controls.Add(Me.GroupBoxUnit)
        Me.GroupBoxTraining.Controls.Add(Me.GroupBoxModus)
        Me.GroupBoxTraining.Location = New System.Drawing.Point(220, 23)
        Me.GroupBoxTraining.Name = "GroupBoxTraining"
        Me.GroupBoxTraining.Size = New System.Drawing.Size(393, 549)
        Me.GroupBoxTraining.TabIndex = 1
        Me.GroupBoxTraining.TabStop = False
        Me.GroupBoxTraining.Text = "Übung"
        '
        'GroupBoxUnit
        '
        Me.GroupBoxUnit.Controls.Add(Me.ButtonCorrect)
        Me.GroupBoxUnit.Controls.Add(Me.LabelWordTimestamp)
        Me.GroupBoxUnit.Controls.Add(Me.LabelWordState)
        Me.GroupBoxUnit.Controls.Add(Me.RichTextBoxWordInfo)
        Me.GroupBoxUnit.Controls.Add(Me.LabelWordToCheck5)
        Me.GroupBoxUnit.Controls.Add(Me.LabelWordToCheck4)
        Me.GroupBoxUnit.Controls.Add(Me.LabelWordToCheck3)
        Me.GroupBoxUnit.Controls.Add(Me.LabelWordToCheck2)
        Me.GroupBoxUnit.Controls.Add(Me.LabelWordToCheck1)
        Me.GroupBoxUnit.Controls.Add(Me.LabelWordGiven)
        Me.GroupBoxUnit.Controls.Add(Me.ButtonGoOn)
        Me.GroupBoxUnit.Controls.Add(Me.LabelHint)
        Me.GroupBoxUnit.Location = New System.Drawing.Point(16, 117)
        Me.GroupBoxUnit.Name = "GroupBoxUnit"
        Me.GroupBoxUnit.Size = New System.Drawing.Size(362, 414)
        Me.GroupBoxUnit.TabIndex = 1
        Me.GroupBoxUnit.TabStop = False
        Me.GroupBoxUnit.Text = "Lerneinheit"
        '
        'ButtonCorrect
        '
        Me.ButtonCorrect.Location = New System.Drawing.Point(93, 32)
        Me.ButtonCorrect.Name = "ButtonCorrect"
        Me.ButtonCorrect.Size = New System.Drawing.Size(69, 24)
        Me.ButtonCorrect.TabIndex = 11
        Me.ButtonCorrect.Text = "richtig"
        Me.ButtonCorrect.UseVisualStyleBackColor = True
        '
        'LabelWordTimestamp
        '
        Me.LabelWordTimestamp.AutoSize = True
        Me.LabelWordTimestamp.Location = New System.Drawing.Point(16, 73)
        Me.LabelWordTimestamp.Name = "LabelWordTimestamp"
        Me.LabelWordTimestamp.Size = New System.Drawing.Size(87, 13)
        Me.LabelWordTimestamp.TabIndex = 10
        Me.LabelWordTimestamp.Text = "Wort Zeitstempel"
        '
        'LabelWordState
        '
        Me.LabelWordState.AutoSize = True
        Me.LabelWordState.Location = New System.Drawing.Point(16, 55)
        Me.LabelWordState.Name = "LabelWordState"
        Me.LabelWordState.Size = New System.Drawing.Size(63, 13)
        Me.LabelWordState.TabIndex = 9
        Me.LabelWordState.Text = "Wort Status"
        '
        'RichTextBoxWordInfo
        '
        Me.RichTextBoxWordInfo.BackColor = System.Drawing.Color.LightYellow
        Me.RichTextBoxWordInfo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBoxWordInfo.Location = New System.Drawing.Point(174, 32)
        Me.RichTextBoxWordInfo.Name = "RichTextBoxWordInfo"
        Me.RichTextBoxWordInfo.Size = New System.Drawing.Size(171, 57)
        Me.RichTextBoxWordInfo.TabIndex = 8
        Me.RichTextBoxWordInfo.Text = "Wort Info"
        '
        'LabelWordToCheck5
        '
        Me.LabelWordToCheck5.BackColor = System.Drawing.Color.LightSkyBlue
        Me.LabelWordToCheck5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelWordToCheck5.Location = New System.Drawing.Point(15, 360)
        Me.LabelWordToCheck5.Name = "LabelWordToCheck5"
        Me.LabelWordToCheck5.Size = New System.Drawing.Size(330, 41)
        Me.LabelWordToCheck5.TabIndex = 7
        Me.LabelWordToCheck5.Text = "Check5"
        Me.LabelWordToCheck5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelWordToCheck4
        '
        Me.LabelWordToCheck4.BackColor = System.Drawing.Color.LightSkyBlue
        Me.LabelWordToCheck4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelWordToCheck4.Location = New System.Drawing.Point(15, 307)
        Me.LabelWordToCheck4.Name = "LabelWordToCheck4"
        Me.LabelWordToCheck4.Size = New System.Drawing.Size(330, 41)
        Me.LabelWordToCheck4.TabIndex = 6
        Me.LabelWordToCheck4.Text = "Check4"
        Me.LabelWordToCheck4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelWordToCheck3
        '
        Me.LabelWordToCheck3.BackColor = System.Drawing.Color.LightSkyBlue
        Me.LabelWordToCheck3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelWordToCheck3.Location = New System.Drawing.Point(15, 254)
        Me.LabelWordToCheck3.Name = "LabelWordToCheck3"
        Me.LabelWordToCheck3.Size = New System.Drawing.Size(330, 41)
        Me.LabelWordToCheck3.TabIndex = 5
        Me.LabelWordToCheck3.Text = "Check3"
        Me.LabelWordToCheck3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelWordToCheck2
        '
        Me.LabelWordToCheck2.BackColor = System.Drawing.Color.LightSkyBlue
        Me.LabelWordToCheck2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelWordToCheck2.Location = New System.Drawing.Point(15, 201)
        Me.LabelWordToCheck2.Name = "LabelWordToCheck2"
        Me.LabelWordToCheck2.Size = New System.Drawing.Size(330, 41)
        Me.LabelWordToCheck2.TabIndex = 4
        Me.LabelWordToCheck2.Text = "Check2"
        Me.LabelWordToCheck2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelWordToCheck1
        '
        Me.LabelWordToCheck1.BackColor = System.Drawing.Color.LightSkyBlue
        Me.LabelWordToCheck1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelWordToCheck1.Location = New System.Drawing.Point(15, 148)
        Me.LabelWordToCheck1.Name = "LabelWordToCheck1"
        Me.LabelWordToCheck1.Size = New System.Drawing.Size(330, 41)
        Me.LabelWordToCheck1.TabIndex = 3
        Me.LabelWordToCheck1.Text = "Check1"
        Me.LabelWordToCheck1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelWordGiven
        '
        Me.LabelWordGiven.BackColor = System.Drawing.Color.LightYellow
        Me.LabelWordGiven.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelWordGiven.Location = New System.Drawing.Point(15, 95)
        Me.LabelWordGiven.Name = "LabelWordGiven"
        Me.LabelWordGiven.Size = New System.Drawing.Size(330, 41)
        Me.LabelWordGiven.TabIndex = 2
        Me.LabelWordGiven.Text = "Wort"
        Me.LabelWordGiven.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ButtonGoOn
        '
        Me.ButtonGoOn.Location = New System.Drawing.Point(15, 23)
        Me.ButtonGoOn.Name = "ButtonGoOn"
        Me.ButtonGoOn.Size = New System.Drawing.Size(69, 24)
        Me.ButtonGoOn.TabIndex = 1
        Me.ButtonGoOn.Text = "Weiter"
        Me.ButtonGoOn.UseVisualStyleBackColor = True
        '
        'LabelHint
        '
        Me.LabelHint.AutoSize = True
        Me.LabelHint.Location = New System.Drawing.Point(90, 16)
        Me.LabelHint.Name = "LabelHint"
        Me.LabelHint.Size = New System.Drawing.Size(73, 13)
        Me.LabelHint.TabIndex = 0
        Me.LabelHint.Text = "Nutzerhinweis"
        '
        'GroupBoxModus
        '
        Me.GroupBoxModus.Controls.Add(Me.CheckBoxAutomatic)
        Me.GroupBoxModus.Controls.Add(Me.LabelNumWords)
        Me.GroupBoxModus.Controls.Add(Me.ButtonStartUnit)
        Me.GroupBoxModus.Controls.Add(Me.ComboBoxNumberOfTimes)
        Me.GroupBoxModus.Controls.Add(Me.ComboBoxNumberOfWords)
        Me.GroupBoxModus.Controls.Add(Me.LabelNumberOfTimes)
        Me.GroupBoxModus.Controls.Add(Me.LabelNumberOfWords)
        Me.GroupBoxModus.Controls.Add(Me.RadioButtonMixed)
        Me.GroupBoxModus.Controls.Add(Me.RadioButtonOldWords)
        Me.GroupBoxModus.Controls.Add(Me.RadioButtonNewWords)
        Me.GroupBoxModus.Location = New System.Drawing.Point(16, 19)
        Me.GroupBoxModus.Name = "GroupBoxModus"
        Me.GroupBoxModus.Size = New System.Drawing.Size(362, 92)
        Me.GroupBoxModus.TabIndex = 0
        Me.GroupBoxModus.TabStop = False
        Me.GroupBoxModus.Text = "Training Modus"
        '
        'CheckBoxAutomatic
        '
        Me.CheckBoxAutomatic.AutoSize = True
        Me.CheckBoxAutomatic.Location = New System.Drawing.Point(155, 66)
        Me.CheckBoxAutomatic.Name = "CheckBoxAutomatic"
        Me.CheckBoxAutomatic.Size = New System.Drawing.Size(48, 17)
        Me.CheckBoxAutomatic.TabIndex = 9
        Me.CheckBoxAutomatic.Text = "Auto"
        Me.CheckBoxAutomatic.UseVisualStyleBackColor = True
        '
        'LabelNumWords
        '
        Me.LabelNumWords.AutoSize = True
        Me.LabelNumWords.Location = New System.Drawing.Point(293, 67)
        Me.LabelNumWords.Name = "LabelNumWords"
        Me.LabelNumWords.Size = New System.Drawing.Size(42, 13)
        Me.LabelNumWords.TabIndex = 8
        Me.LabelNumWords.Text = "Wörter:"
        '
        'ButtonStartUnit
        '
        Me.ButtonStartUnit.Location = New System.Drawing.Point(204, 62)
        Me.ButtonStartUnit.Name = "ButtonStartUnit"
        Me.ButtonStartUnit.Size = New System.Drawing.Size(78, 24)
        Me.ButtonStartUnit.TabIndex = 7
        Me.ButtonStartUnit.Text = "Start Unit"
        Me.ButtonStartUnit.UseVisualStyleBackColor = True
        '
        'ComboBoxNumberOfTimes
        '
        Me.ComboBoxNumberOfTimes.FormattingEnabled = True
        Me.ComboBoxNumberOfTimes.Location = New System.Drawing.Point(295, 41)
        Me.ComboBoxNumberOfTimes.Name = "ComboBoxNumberOfTimes"
        Me.ComboBoxNumberOfTimes.Size = New System.Drawing.Size(50, 21)
        Me.ComboBoxNumberOfTimes.TabIndex = 6
        '
        'ComboBoxNumberOfWords
        '
        Me.ComboBoxNumberOfWords.FormattingEnabled = True
        Me.ComboBoxNumberOfWords.Location = New System.Drawing.Point(295, 19)
        Me.ComboBoxNumberOfWords.Name = "ComboBoxNumberOfWords"
        Me.ComboBoxNumberOfWords.Size = New System.Drawing.Size(50, 21)
        Me.ComboBoxNumberOfWords.TabIndex = 5
        '
        'LabelNumberOfTimes
        '
        Me.LabelNumberOfTimes.AutoSize = True
        Me.LabelNumberOfTimes.Location = New System.Drawing.Point(171, 44)
        Me.LabelNumberOfTimes.Name = "LabelNumberOfTimes"
        Me.LabelNumberOfTimes.Size = New System.Drawing.Size(94, 13)
        Me.LabelNumberOfTimes.TabIndex = 4
        Me.LabelNumberOfTimes.Text = "Anzahl Durchläufe"
        '
        'LabelNumberOfWords
        '
        Me.LabelNumberOfWords.AutoSize = True
        Me.LabelNumberOfWords.Location = New System.Drawing.Point(171, 21)
        Me.LabelNumberOfWords.Name = "LabelNumberOfWords"
        Me.LabelNumberOfWords.Size = New System.Drawing.Size(74, 13)
        Me.LabelNumberOfWords.TabIndex = 3
        Me.LabelNumberOfWords.Text = "Anzahl Wörter"
        '
        'RadioButtonMixed
        '
        Me.RadioButtonMixed.AutoSize = True
        Me.RadioButtonMixed.Location = New System.Drawing.Point(15, 65)
        Me.RadioButtonMixed.Name = "RadioButtonMixed"
        Me.RadioButtonMixed.Size = New System.Drawing.Size(69, 17)
        Me.RadioButtonMixed.TabIndex = 2
        Me.RadioButtonMixed.TabStop = True
        Me.RadioButtonMixed.Text = "Gemischt"
        Me.RadioButtonMixed.UseVisualStyleBackColor = True
        '
        'RadioButtonOldWords
        '
        Me.RadioButtonOldWords.AutoSize = True
        Me.RadioButtonOldWords.Location = New System.Drawing.Point(15, 42)
        Me.RadioButtonOldWords.Name = "RadioButtonOldWords"
        Me.RadioButtonOldWords.Size = New System.Drawing.Size(106, 17)
        Me.RadioButtonOldWords.TabIndex = 1
        Me.RadioButtonOldWords.TabStop = True
        Me.RadioButtonOldWords.Text = "Bekannte Wörter"
        Me.RadioButtonOldWords.UseVisualStyleBackColor = True
        '
        'RadioButtonNewWords
        '
        Me.RadioButtonNewWords.AutoSize = True
        Me.RadioButtonNewWords.Location = New System.Drawing.Point(15, 19)
        Me.RadioButtonNewWords.Name = "RadioButtonNewWords"
        Me.RadioButtonNewWords.Size = New System.Drawing.Size(86, 17)
        Me.RadioButtonNewWords.TabIndex = 0
        Me.RadioButtonNewWords.TabStop = True
        Me.RadioButtonNewWords.Text = "Neue Wörter"
        Me.RadioButtonNewWords.UseVisualStyleBackColor = True
        '
        'ButtonOK
        '
        Me.ButtonOK.Location = New System.Drawing.Point(134, 544)
        Me.ButtonOK.Name = "ButtonOK"
        Me.ButtonOK.Size = New System.Drawing.Size(47, 28)
        Me.ButtonOK.TabIndex = 4
        Me.ButtonOK.Text = "Save"
        Me.ButtonOK.UseVisualStyleBackColor = True
        '
        'ButtonStart
        '
        Me.ButtonStart.Location = New System.Drawing.Point(34, 544)
        Me.ButtonStart.Name = "ButtonStart"
        Me.ButtonStart.Size = New System.Drawing.Size(93, 28)
        Me.ButtonStart.TabIndex = 3
        Me.ButtonStart.Text = "Start Training"
        Me.ButtonStart.UseVisualStyleBackColor = True
        '
        'CheckBoxC1
        '
        Me.CheckBoxC1.AutoSize = True
        Me.CheckBoxC1.Location = New System.Drawing.Point(76, 23)
        Me.CheckBoxC1.Name = "CheckBoxC1"
        Me.CheckBoxC1.Size = New System.Drawing.Size(39, 17)
        Me.CheckBoxC1.TabIndex = 4
        Me.CheckBoxC1.Text = "C1"
        Me.CheckBoxC1.UseVisualStyleBackColor = True
        '
        'CheckBoxC2
        '
        Me.CheckBoxC2.AutoSize = True
        Me.CheckBoxC2.Location = New System.Drawing.Point(76, 46)
        Me.CheckBoxC2.Name = "CheckBoxC2"
        Me.CheckBoxC2.Size = New System.Drawing.Size(39, 17)
        Me.CheckBoxC2.TabIndex = 5
        Me.CheckBoxC2.Text = "C2"
        Me.CheckBoxC2.UseVisualStyleBackColor = True
        '
        'CheckBoxEX
        '
        Me.CheckBoxEX.AutoSize = True
        Me.CheckBoxEX.Location = New System.Drawing.Point(76, 69)
        Me.CheckBoxEX.Name = "CheckBoxEX"
        Me.CheckBoxEX.Size = New System.Drawing.Size(50, 17)
        Me.CheckBoxEX.TabIndex = 6
        Me.CheckBoxEX.Text = "Extra"
        Me.CheckBoxEX.UseVisualStyleBackColor = True
        '
        'FTrainer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(637, 597)
        Me.Controls.Add(Me.ButtonStart)
        Me.Controls.Add(Me.ButtonOK)
        Me.Controls.Add(Me.GroupBoxTraining)
        Me.Controls.Add(Me.GroupBoxSelection)
        Me.Name = "FTrainer"
        Me.Text = "Vocabulary Trainer"
        Me.GroupBoxSelection.ResumeLayout(False)
        Me.GroupBoxLanguages.ResumeLayout(False)
        Me.GroupBoxLanguages.PerformLayout()
        Me.GroupBoxResults.ResumeLayout(False)
        Me.GroupBoxResults.PerformLayout()
        Me.GroupBoxNiveaus.ResumeLayout(False)
        Me.GroupBoxNiveaus.PerformLayout()
        Me.GroupBoxChoice.ResumeLayout(False)
        Me.GroupBoxChoice.PerformLayout()
        Me.GroupBoxTraining.ResumeLayout(False)
        Me.GroupBoxUnit.ResumeLayout(False)
        Me.GroupBoxUnit.PerformLayout()
        Me.GroupBoxModus.ResumeLayout(False)
        Me.GroupBoxModus.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBoxSelection As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBoxTraining As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBoxChoice As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButtonNewChoice As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButtonUseChoice As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButtonAppendChoice As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBoxNiveaus As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBoxB2 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBoxB1 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBoxA2 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBoxA1 As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBoxResults As System.Windows.Forms.GroupBox
    Friend WithEvents LabelDone As System.Windows.Forms.Label
    Friend WithEvents LabelSelected As System.Windows.Forms.Label
    Friend WithEvents LabelStaticScore As System.Windows.Forms.Label
    Friend WithEvents LabelStaticDone As System.Windows.Forms.Label
    Friend WithEvents LabelStaticSelected As System.Windows.Forms.Label
    Friend WithEvents LabelScore As System.Windows.Forms.Label
    Friend WithEvents ButtonOK As System.Windows.Forms.Button
    Friend WithEvents GroupBoxLanguages As System.Windows.Forms.GroupBox
    Friend WithEvents LabelToLang As System.Windows.Forms.Label
    Friend WithEvents LabelFromLang As System.Windows.Forms.Label
    Friend WithEvents ComboBoxToLang As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxFromLang As System.Windows.Forms.ComboBox
    Friend WithEvents ButtonApply As System.Windows.Forms.Button
    Friend WithEvents ButtonStart As System.Windows.Forms.Button
    Friend WithEvents GroupBoxModus As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButtonMixed As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButtonOldWords As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButtonNewWords As System.Windows.Forms.RadioButton
    Friend WithEvents ComboBoxNumberOfWords As System.Windows.Forms.ComboBox
    Friend WithEvents LabelNumberOfTimes As System.Windows.Forms.Label
    Friend WithEvents LabelNumberOfWords As System.Windows.Forms.Label
    Friend WithEvents ComboBoxNumberOfTimes As System.Windows.Forms.ComboBox
    Friend WithEvents ButtonStartUnit As System.Windows.Forms.Button
    Friend WithEvents GroupBoxUnit As System.Windows.Forms.GroupBox
    Friend WithEvents LabelHint As System.Windows.Forms.Label
    Friend WithEvents ButtonGoOn As System.Windows.Forms.Button
    Friend WithEvents LabelWordGiven As System.Windows.Forms.Label
    Friend WithEvents LabelWordToCheck1 As System.Windows.Forms.Label
    Friend WithEvents LabelWordToCheck5 As System.Windows.Forms.Label
    Friend WithEvents LabelWordToCheck4 As System.Windows.Forms.Label
    Friend WithEvents LabelWordToCheck3 As System.Windows.Forms.Label
    Friend WithEvents LabelWordToCheck2 As System.Windows.Forms.Label
    Friend WithEvents RichTextBoxWordInfo As System.Windows.Forms.RichTextBox
    Friend WithEvents LabelNumWords As System.Windows.Forms.Label
    Friend WithEvents LabelWordState As System.Windows.Forms.Label
    Friend WithEvents LabelWordTimestamp As System.Windows.Forms.Label
    Friend WithEvents ButtonCorrect As System.Windows.Forms.Button
    Friend WithEvents CheckBoxAutomatic As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBoxEX As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBoxC2 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBoxC1 As System.Windows.Forms.CheckBox
End Class
