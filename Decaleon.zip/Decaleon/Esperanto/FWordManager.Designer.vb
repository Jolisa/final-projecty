﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FWordManager
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBoxImport = New System.Windows.Forms.GroupBox
        Me.LabelResult = New System.Windows.Forms.Label
        Me.ButtonImport = New System.Windows.Forms.Button
        Me.CheckBoxFirstLine = New System.Windows.Forms.CheckBox
        Me.DataGridViewMatch = New System.Windows.Forms.DataGridView
        Me.ColumnDestination = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ColumnSource = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ButtonClearDgrid = New System.Windows.Forms.Button
        Me.ButtonAddPair = New System.Windows.Forms.Button
        Me.ListBoxCSVdata = New System.Windows.Forms.ListBox
        Me.ListBoxWordData = New System.Windows.Forms.ListBox
        Me.LabelUser2 = New System.Windows.Forms.Label
        Me.ButtonOpen = New System.Windows.Forms.Button
        Me.ComboBoxSeparator = New System.Windows.Forms.ComboBox
        Me.LabelUser1 = New System.Windows.Forms.Label
        Me.ListBoxIndexCSV = New System.Windows.Forms.ListBox
        Me.GroupBoxRegister = New System.Windows.Forms.GroupBox
        Me.ButtonResetWreg = New System.Windows.Forms.Button
        Me.ComboBoxTheme = New System.Windows.Forms.ComboBox
        Me.LabelTheme = New System.Windows.Forms.Label
        Me.LabelCounter = New System.Windows.Forms.Label
        Me.ButtonRegister = New System.Windows.Forms.Button
        Me.TextBoxSynonym = New System.Windows.Forms.TextBox
        Me.TextBoxContext = New System.Windows.Forms.TextBox
        Me.TextBoxToLang = New System.Windows.Forms.TextBox
        Me.TextBoxFromLang = New System.Windows.Forms.TextBox
        Me.LabelSynonym = New System.Windows.Forms.Label
        Me.LabelContext = New System.Windows.Forms.Label
        Me.ComboBox2ndLang = New System.Windows.Forms.ComboBox
        Me.ComboBox1stLang = New System.Windows.Forms.ComboBox
        Me.LabelUser3 = New System.Windows.Forms.Label
        Me.ButtonOK = New System.Windows.Forms.Button
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.ListBoxIndexWord = New System.Windows.Forms.ListBox
        Me.LabelUser4 = New System.Windows.Forms.Label
        Me.ComboBoxFromLang = New System.Windows.Forms.ComboBox
        Me.ComboBoxToLang = New System.Windows.Forms.ComboBox
        Me.LabelFromLang = New System.Windows.Forms.Label
        Me.LabelToLang = New System.Windows.Forms.Label
        Me.GroupBoxImport.SuspendLayout()
        CType(Me.DataGridViewMatch, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBoxRegister.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBoxImport
        '
        Me.GroupBoxImport.Controls.Add(Me.LabelResult)
        Me.GroupBoxImport.Controls.Add(Me.ButtonImport)
        Me.GroupBoxImport.Controls.Add(Me.CheckBoxFirstLine)
        Me.GroupBoxImport.Controls.Add(Me.DataGridViewMatch)
        Me.GroupBoxImport.Controls.Add(Me.ButtonClearDgrid)
        Me.GroupBoxImport.Controls.Add(Me.ButtonAddPair)
        Me.GroupBoxImport.Controls.Add(Me.ListBoxCSVdata)
        Me.GroupBoxImport.Controls.Add(Me.ListBoxWordData)
        Me.GroupBoxImport.Controls.Add(Me.LabelUser2)
        Me.GroupBoxImport.Controls.Add(Me.ButtonOpen)
        Me.GroupBoxImport.Controls.Add(Me.ComboBoxSeparator)
        Me.GroupBoxImport.Controls.Add(Me.LabelUser1)
        Me.GroupBoxImport.Location = New System.Drawing.Point(23, 18)
        Me.GroupBoxImport.Name = "GroupBoxImport"
        Me.GroupBoxImport.Size = New System.Drawing.Size(411, 377)
        Me.GroupBoxImport.TabIndex = 0
        Me.GroupBoxImport.TabStop = False
        Me.GroupBoxImport.Text = "Import"
        '
        'LabelResult
        '
        Me.LabelResult.AutoSize = True
        Me.LabelResult.Location = New System.Drawing.Point(265, 342)
        Me.LabelResult.Name = "LabelResult"
        Me.LabelResult.Size = New System.Drawing.Size(48, 13)
        Me.LabelResult.TabIndex = 11
        Me.LabelResult.Text = "Ergebnis"
        '
        'ButtonImport
        '
        Me.ButtonImport.Location = New System.Drawing.Point(146, 335)
        Me.ButtonImport.Name = "ButtonImport"
        Me.ButtonImport.Size = New System.Drawing.Size(114, 27)
        Me.ButtonImport.TabIndex = 10
        Me.ButtonImport.Text = "Import starten"
        Me.ButtonImport.UseVisualStyleBackColor = True
        '
        'CheckBoxFirstLine
        '
        Me.CheckBoxFirstLine.AutoSize = True
        Me.CheckBoxFirstLine.Location = New System.Drawing.Point(15, 341)
        Me.CheckBoxFirstLine.Name = "CheckBoxFirstLine"
        Me.CheckBoxFirstLine.Size = New System.Drawing.Size(125, 17)
        Me.CheckBoxFirstLine.TabIndex = 9
        Me.CheckBoxFirstLine.Text = "Erste Zeile ignorieren"
        Me.CheckBoxFirstLine.UseVisualStyleBackColor = True
        '
        'DataGridViewMatch
        '
        Me.DataGridViewMatch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewMatch.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ColumnDestination, Me.ColumnSource})
        Me.DataGridViewMatch.Location = New System.Drawing.Point(15, 222)
        Me.DataGridViewMatch.Name = "DataGridViewMatch"
        Me.DataGridViewMatch.Size = New System.Drawing.Size(377, 96)
        Me.DataGridViewMatch.TabIndex = 8
        '
        'ColumnDestination
        '
        Me.ColumnDestination.HeaderText = "Ziel"
        Me.ColumnDestination.Name = "ColumnDestination"
        Me.ColumnDestination.Width = 150
        '
        'ColumnSource
        '
        Me.ColumnSource.HeaderText = "Quelle"
        Me.ColumnSource.Name = "ColumnSource"
        Me.ColumnSource.Width = 150
        '
        'ButtonClearDgrid
        '
        Me.ButtonClearDgrid.Location = New System.Drawing.Point(321, 189)
        Me.ButtonClearDgrid.Name = "ButtonClearDgrid"
        Me.ButtonClearDgrid.Size = New System.Drawing.Size(61, 27)
        Me.ButtonClearDgrid.TabIndex = 7
        Me.ButtonClearDgrid.Text = "Clear"
        Me.ButtonClearDgrid.UseVisualStyleBackColor = True
        '
        'ButtonAddPair
        '
        Me.ButtonAddPair.Location = New System.Drawing.Point(153, 189)
        Me.ButtonAddPair.Name = "ButtonAddPair"
        Me.ButtonAddPair.Size = New System.Drawing.Size(88, 27)
        Me.ButtonAddPair.TabIndex = 6
        Me.ButtonAddPair.Text = "Hinzufügen"
        Me.ButtonAddPair.UseVisualStyleBackColor = True
        '
        'ListBoxCSVdata
        '
        Me.ListBoxCSVdata.FormattingEnabled = True
        Me.ListBoxCSVdata.Location = New System.Drawing.Point(223, 114)
        Me.ListBoxCSVdata.Name = "ListBoxCSVdata"
        Me.ListBoxCSVdata.Size = New System.Drawing.Size(169, 69)
        Me.ListBoxCSVdata.TabIndex = 5
        '
        'ListBoxWordData
        '
        Me.ListBoxWordData.FormattingEnabled = True
        Me.ListBoxWordData.Location = New System.Drawing.Point(15, 114)
        Me.ListBoxWordData.Name = "ListBoxWordData"
        Me.ListBoxWordData.Size = New System.Drawing.Size(164, 69)
        Me.ListBoxWordData.TabIndex = 4
        '
        'LabelUser2
        '
        Me.LabelUser2.AutoSize = True
        Me.LabelUser2.Location = New System.Drawing.Point(12, 88)
        Me.LabelUser2.Name = "LabelUser2"
        Me.LabelUser2.Size = New System.Drawing.Size(308, 13)
        Me.LabelUser2.TabIndex = 3
        Me.LabelUser2.Text = "Bitte 2 Sprachen und ggf. Kontext- und Synonym-Info zuordnen!"
        '
        'ButtonOpen
        '
        Me.ButtonOpen.Location = New System.Drawing.Point(268, 24)
        Me.ButtonOpen.Name = "ButtonOpen"
        Me.ButtonOpen.Size = New System.Drawing.Size(124, 44)
        Me.ButtonOpen.TabIndex = 2
        Me.ButtonOpen.Text = "CSV Datei öffnen"
        Me.ButtonOpen.UseVisualStyleBackColor = True
        '
        'ComboBoxSeparator
        '
        Me.ComboBoxSeparator.FormattingEnabled = True
        Me.ComboBoxSeparator.Location = New System.Drawing.Point(101, 47)
        Me.ComboBoxSeparator.Name = "ComboBoxSeparator"
        Me.ComboBoxSeparator.Size = New System.Drawing.Size(78, 21)
        Me.ComboBoxSeparator.TabIndex = 1
        '
        'LabelUser1
        '
        Me.LabelUser1.AutoSize = True
        Me.LabelUser1.Location = New System.Drawing.Point(12, 24)
        Me.LabelUser1.Name = "LabelUser1"
        Me.LabelUser1.Size = New System.Drawing.Size(207, 13)
        Me.LabelUser1.TabIndex = 0
        Me.LabelUser1.Text = "Bitte Trennzeichen wählen oder eingeben!"
        '
        'ListBoxIndexCSV
        '
        Me.ListBoxIndexCSV.FormattingEnabled = True
        Me.ListBoxIndexCSV.Location = New System.Drawing.Point(435, 132)
        Me.ListBoxIndexCSV.Name = "ListBoxIndexCSV"
        Me.ListBoxIndexCSV.Size = New System.Drawing.Size(11, 69)
        Me.ListBoxIndexCSV.TabIndex = 13
        '
        'GroupBoxRegister
        '
        Me.GroupBoxRegister.Controls.Add(Me.ButtonResetWreg)
        Me.GroupBoxRegister.Controls.Add(Me.ComboBoxTheme)
        Me.GroupBoxRegister.Controls.Add(Me.LabelTheme)
        Me.GroupBoxRegister.Controls.Add(Me.LabelCounter)
        Me.GroupBoxRegister.Controls.Add(Me.ButtonRegister)
        Me.GroupBoxRegister.Controls.Add(Me.TextBoxSynonym)
        Me.GroupBoxRegister.Controls.Add(Me.TextBoxContext)
        Me.GroupBoxRegister.Controls.Add(Me.TextBoxToLang)
        Me.GroupBoxRegister.Controls.Add(Me.TextBoxFromLang)
        Me.GroupBoxRegister.Controls.Add(Me.LabelSynonym)
        Me.GroupBoxRegister.Controls.Add(Me.LabelContext)
        Me.GroupBoxRegister.Controls.Add(Me.ComboBox2ndLang)
        Me.GroupBoxRegister.Controls.Add(Me.ComboBox1stLang)
        Me.GroupBoxRegister.Controls.Add(Me.LabelUser3)
        Me.GroupBoxRegister.Location = New System.Drawing.Point(23, 401)
        Me.GroupBoxRegister.Name = "GroupBoxRegister"
        Me.GroupBoxRegister.Size = New System.Drawing.Size(411, 235)
        Me.GroupBoxRegister.TabIndex = 1
        Me.GroupBoxRegister.TabStop = False
        Me.GroupBoxRegister.Text = "Erfassen"
        '
        'ButtonResetWreg
        '
        Me.ButtonResetWreg.Location = New System.Drawing.Point(321, 191)
        Me.ButtonResetWreg.Name = "ButtonResetWreg"
        Me.ButtonResetWreg.Size = New System.Drawing.Size(61, 27)
        Me.ButtonResetWreg.TabIndex = 13
        Me.ButtonResetWreg.Text = "Reset"
        Me.ButtonResetWreg.UseVisualStyleBackColor = True
        '
        'ComboBoxTheme
        '
        Me.ComboBoxTheme.FormattingEnabled = True
        Me.ComboBoxTheme.Location = New System.Drawing.Point(151, 162)
        Me.ComboBoxTheme.Name = "ComboBoxTheme"
        Me.ComboBoxTheme.Size = New System.Drawing.Size(241, 21)
        Me.ComboBoxTheme.TabIndex = 10
        '
        'LabelTheme
        '
        Me.LabelTheme.AutoSize = True
        Me.LabelTheme.Location = New System.Drawing.Point(18, 165)
        Me.LabelTheme.Name = "LabelTheme"
        Me.LabelTheme.Size = New System.Drawing.Size(80, 13)
        Me.LabelTheme.TabIndex = 9
        Me.LabelTheme.Text = "Thema wählen!"
        '
        'LabelCounter
        '
        Me.LabelCounter.AutoSize = True
        Me.LabelCounter.Location = New System.Drawing.Point(148, 198)
        Me.LabelCounter.Name = "LabelCounter"
        Me.LabelCounter.Size = New System.Drawing.Size(37, 13)
        Me.LabelCounter.TabIndex = 12
        Me.LabelCounter.Text = "Zähler"
        '
        'ButtonRegister
        '
        Me.ButtonRegister.Location = New System.Drawing.Point(15, 191)
        Me.ButtonRegister.Name = "ButtonRegister"
        Me.ButtonRegister.Size = New System.Drawing.Size(114, 27)
        Me.ButtonRegister.TabIndex = 11
        Me.ButtonRegister.Text = "Erfassen"
        Me.ButtonRegister.UseVisualStyleBackColor = True
        '
        'TextBoxSynonym
        '
        Me.TextBoxSynonym.Location = New System.Drawing.Point(151, 134)
        Me.TextBoxSynonym.Name = "TextBoxSynonym"
        Me.TextBoxSynonym.Size = New System.Drawing.Size(241, 20)
        Me.TextBoxSynonym.TabIndex = 8
        '
        'TextBoxContext
        '
        Me.TextBoxContext.Location = New System.Drawing.Point(151, 105)
        Me.TextBoxContext.Name = "TextBoxContext"
        Me.TextBoxContext.Size = New System.Drawing.Size(241, 20)
        Me.TextBoxContext.TabIndex = 7
        '
        'TextBoxToLang
        '
        Me.TextBoxToLang.Location = New System.Drawing.Point(152, 75)
        Me.TextBoxToLang.Name = "TextBoxToLang"
        Me.TextBoxToLang.Size = New System.Drawing.Size(240, 20)
        Me.TextBoxToLang.TabIndex = 6
        '
        'TextBoxFromLang
        '
        Me.TextBoxFromLang.Location = New System.Drawing.Point(152, 47)
        Me.TextBoxFromLang.Name = "TextBoxFromLang"
        Me.TextBoxFromLang.Size = New System.Drawing.Size(240, 20)
        Me.TextBoxFromLang.TabIndex = 5
        '
        'LabelSynonym
        '
        Me.LabelSynonym.AutoSize = True
        Me.LabelSynonym.Location = New System.Drawing.Point(18, 137)
        Me.LabelSynonym.Name = "LabelSynonym"
        Me.LabelSynonym.Size = New System.Drawing.Size(71, 13)
        Me.LabelSynonym.TabIndex = 4
        Me.LabelSynonym.Text = "Synonym-Info"
        '
        'LabelContext
        '
        Me.LabelContext.AutoSize = True
        Me.LabelContext.Location = New System.Drawing.Point(18, 108)
        Me.LabelContext.Name = "LabelContext"
        Me.LabelContext.Size = New System.Drawing.Size(64, 13)
        Me.LabelContext.TabIndex = 3
        Me.LabelContext.Text = "Kontext-Info"
        '
        'ComboBox2ndLang
        '
        Me.ComboBox2ndLang.FormattingEnabled = True
        Me.ComboBox2ndLang.Location = New System.Drawing.Point(15, 74)
        Me.ComboBox2ndLang.Name = "ComboBox2ndLang"
        Me.ComboBox2ndLang.Size = New System.Drawing.Size(114, 21)
        Me.ComboBox2ndLang.TabIndex = 2
        '
        'ComboBox1stLang
        '
        Me.ComboBox1stLang.FormattingEnabled = True
        Me.ComboBox1stLang.Location = New System.Drawing.Point(15, 47)
        Me.ComboBox1stLang.Name = "ComboBox1stLang"
        Me.ComboBox1stLang.Size = New System.Drawing.Size(114, 21)
        Me.ComboBox1stLang.TabIndex = 1
        '
        'LabelUser3
        '
        Me.LabelUser3.AutoSize = True
        Me.LabelUser3.Location = New System.Drawing.Point(12, 20)
        Me.LabelUser3.Name = "LabelUser3"
        Me.LabelUser3.Size = New System.Drawing.Size(299, 13)
        Me.LabelUser3.TabIndex = 0
        Me.LabelUser3.Text = "Bitte 2 Sprachen wählen! Kontext- und Synonym-Info optional!"
        '
        'ButtonOK
        '
        Me.ButtonOK.Location = New System.Drawing.Point(301, 671)
        Me.ButtonOK.Name = "ButtonOK"
        Me.ButtonOK.Size = New System.Drawing.Size(114, 44)
        Me.ButtonOK.TabIndex = 2
        Me.ButtonOK.Text = "Trainingsdatei erzeugen"
        Me.ButtonOK.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'ListBoxIndexWord
        '
        Me.ListBoxIndexWord.FormattingEnabled = True
        Me.ListBoxIndexWord.Location = New System.Drawing.Point(12, 132)
        Me.ListBoxIndexWord.Name = "ListBoxIndexWord"
        Me.ListBoxIndexWord.Size = New System.Drawing.Size(10, 69)
        Me.ListBoxIndexWord.TabIndex = 12
        '
        'LabelUser4
        '
        Me.LabelUser4.AutoSize = True
        Me.LabelUser4.Location = New System.Drawing.Point(39, 654)
        Me.LabelUser4.Name = "LabelUser4"
        Me.LabelUser4.Size = New System.Drawing.Size(126, 13)
        Me.LabelUser4.TabIndex = 14
        Me.LabelUser4.Text = "Bitte 2 Sprachen wählen!"
        '
        'ComboBoxFromLang
        '
        Me.ComboBoxFromLang.FormattingEnabled = True
        Me.ComboBoxFromLang.Location = New System.Drawing.Point(42, 687)
        Me.ComboBoxFromLang.Name = "ComboBoxFromLang"
        Me.ComboBoxFromLang.Size = New System.Drawing.Size(114, 21)
        Me.ComboBoxFromLang.TabIndex = 15
        '
        'ComboBoxToLang
        '
        Me.ComboBoxToLang.FormattingEnabled = True
        Me.ComboBoxToLang.Location = New System.Drawing.Point(162, 687)
        Me.ComboBoxToLang.Name = "ComboBoxToLang"
        Me.ComboBoxToLang.Size = New System.Drawing.Size(114, 21)
        Me.ComboBoxToLang.TabIndex = 16
        '
        'LabelFromLang
        '
        Me.LabelFromLang.AutoSize = True
        Me.LabelFromLang.Location = New System.Drawing.Point(39, 671)
        Me.LabelFromLang.Name = "LabelFromLang"
        Me.LabelFromLang.Size = New System.Drawing.Size(25, 13)
        Me.LabelFromLang.TabIndex = 17
        Me.LabelFromLang.Text = "von"
        '
        'LabelToLang
        '
        Me.LabelToLang.AutoSize = True
        Me.LabelToLang.Location = New System.Drawing.Point(159, 671)
        Me.LabelToLang.Name = "LabelToLang"
        Me.LabelToLang.Size = New System.Drawing.Size(31, 13)
        Me.LabelToLang.TabIndex = 18
        Me.LabelToLang.Text = "nach"
        '
        'FWordManager
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(458, 734)
        Me.Controls.Add(Me.LabelToLang)
        Me.Controls.Add(Me.LabelFromLang)
        Me.Controls.Add(Me.ComboBoxToLang)
        Me.Controls.Add(Me.ComboBoxFromLang)
        Me.Controls.Add(Me.LabelUser4)
        Me.Controls.Add(Me.ListBoxIndexCSV)
        Me.Controls.Add(Me.ListBoxIndexWord)
        Me.Controls.Add(Me.ButtonOK)
        Me.Controls.Add(Me.GroupBoxRegister)
        Me.Controls.Add(Me.GroupBoxImport)
        Me.Name = "FWordManager"
        Me.Text = "Word Manager"
        Me.GroupBoxImport.ResumeLayout(False)
        Me.GroupBoxImport.PerformLayout()
        CType(Me.DataGridViewMatch, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBoxRegister.ResumeLayout(False)
        Me.GroupBoxRegister.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBoxImport As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBoxRegister As System.Windows.Forms.GroupBox
    Friend WithEvents ButtonOK As System.Windows.Forms.Button
    Friend WithEvents LabelUser1 As System.Windows.Forms.Label
    Friend WithEvents ListBoxCSVdata As System.Windows.Forms.ListBox
    Friend WithEvents ListBoxWordData As System.Windows.Forms.ListBox
    Friend WithEvents LabelUser2 As System.Windows.Forms.Label
    Friend WithEvents ButtonOpen As System.Windows.Forms.Button
    Friend WithEvents ComboBoxSeparator As System.Windows.Forms.ComboBox
    Friend WithEvents ButtonClearDgrid As System.Windows.Forms.Button
    Friend WithEvents ButtonAddPair As System.Windows.Forms.Button
    Friend WithEvents DataGridViewMatch As System.Windows.Forms.DataGridView
    Friend WithEvents ColumnDestination As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ColumnSource As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LabelResult As System.Windows.Forms.Label
    Friend WithEvents ButtonImport As System.Windows.Forms.Button
    Friend WithEvents CheckBoxFirstLine As System.Windows.Forms.CheckBox
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents ListBoxIndexCSV As System.Windows.Forms.ListBox
    Friend WithEvents ListBoxIndexWord As System.Windows.Forms.ListBox
    Friend WithEvents ComboBox1stLang As System.Windows.Forms.ComboBox
    Friend WithEvents LabelUser3 As System.Windows.Forms.Label
    Friend WithEvents ComboBox2ndLang As System.Windows.Forms.ComboBox
    Friend WithEvents TextBoxSynonym As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxContext As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxToLang As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxFromLang As System.Windows.Forms.TextBox
    Friend WithEvents LabelSynonym As System.Windows.Forms.Label
    Friend WithEvents LabelContext As System.Windows.Forms.Label
    Friend WithEvents ButtonRegister As System.Windows.Forms.Button
    Friend WithEvents LabelCounter As System.Windows.Forms.Label
    Friend WithEvents ComboBoxTheme As System.Windows.Forms.ComboBox
    Friend WithEvents LabelTheme As System.Windows.Forms.Label
    Friend WithEvents ButtonResetWreg As System.Windows.Forms.Button
    Friend WithEvents LabelUser4 As System.Windows.Forms.Label
    Friend WithEvents ComboBoxFromLang As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxToLang As System.Windows.Forms.ComboBox
    Friend WithEvents LabelFromLang As System.Windows.Forms.Label
    Friend WithEvents LabelToLang As System.Windows.Forms.Label
End Class
