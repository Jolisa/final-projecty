﻿Option Explicit On

' Vocabulary Trainer between 2 Languages of 10
'
' MP Nov / Dez 2011: Program 3.0
' MP Mar / Apr 2012: Vocabulary Trainer

Public Class FResults

    Public maxWordLength As Integer = 30

    Private Sub FResults_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Vorab

    End Sub

    Private Sub ButtonOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonOK.Click
        ' Close Window
        Close()

    End Sub

End Class