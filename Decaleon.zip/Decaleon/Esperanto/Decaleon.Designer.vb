﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Decaleon
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Decaleon))
        Me.ButtonLoadXML = New System.Windows.Forms.Button
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.LabelOriginal = New System.Windows.Forms.Label
        Me.LabelEsperanto = New System.Windows.Forms.Label
        Me.RichTextBoxOriginal = New System.Windows.Forms.RichTextBox
        Me.RichTextBoxEsperanto = New System.Windows.Forms.RichTextBox
        Me.ButtonTranslate = New System.Windows.Forms.Button
        Me.LabelFehler = New System.Windows.Forms.Label
        Me.TextBoxFehler = New System.Windows.Forms.TextBox
        Me.LabelFile = New System.Windows.Forms.Label
        Me.TextBoxFile = New System.Windows.Forms.TextBox
        Me.ComboBoxLanguage = New System.Windows.Forms.ComboBox
        Me.TreeViewGrammatik = New System.Windows.Forms.TreeView
        Me.LabelTreeView = New System.Windows.Forms.Label
        Me.LabelEdit = New System.Windows.Forms.Label
        Me.LabelEditElement = New System.Windows.Forms.Label
        Me.LabelProperty1 = New System.Windows.Forms.Label
        Me.LabelProperty2 = New System.Windows.Forms.Label
        Me.LabelProperty3 = New System.Windows.Forms.Label
        Me.LabelProperty4 = New System.Windows.Forms.Label
        Me.LabelProperty5 = New System.Windows.Forms.Label
        Me.LabelProperty6 = New System.Windows.Forms.Label
        Me.LabelProperty7 = New System.Windows.Forms.Label
        Me.ComboBoxProperty1 = New System.Windows.Forms.ComboBox
        Me.ComboBoxProperty2 = New System.Windows.Forms.ComboBox
        Me.ComboBoxProperty3 = New System.Windows.Forms.ComboBox
        Me.ComboBoxProperty4 = New System.Windows.Forms.ComboBox
        Me.ComboBoxProperty5 = New System.Windows.Forms.ComboBox
        Me.ComboBoxProperty6 = New System.Windows.Forms.ComboBox
        Me.ComboBoxProperty7 = New System.Windows.Forms.ComboBox
        Me.ButtonSaveEdit = New System.Windows.Forms.Button
        Me.TextBoxEditElement = New System.Windows.Forms.TextBox
        Me.ButtonSaveXML = New System.Windows.Forms.Button
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider
        Me.ButtonHelp = New System.Windows.Forms.Button
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.ButtonDictionary = New System.Windows.Forms.Button
        Me.ToolTip2 = New System.Windows.Forms.ToolTip(Me.components)
        Me.ButtonTrainer = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'ButtonLoadXML
        '
        Me.ButtonLoadXML.Location = New System.Drawing.Point(203, 27)
        Me.ButtonLoadXML.Margin = New System.Windows.Forms.Padding(2)
        Me.ButtonLoadXML.Name = "ButtonLoadXML"
        Me.ButtonLoadXML.Size = New System.Drawing.Size(120, 46)
        Me.ButtonLoadXML.TabIndex = 0
        Me.ButtonLoadXML.Text = "XML-Grammatik  laden ..."
        Me.ToolTip1.SetToolTip(Me.ButtonLoadXML, "Load XML File containing the Sentence Grammar")
        Me.ButtonLoadXML.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'LabelOriginal
        '
        Me.LabelOriginal.AutoSize = True
        Me.LabelOriginal.Location = New System.Drawing.Point(39, 132)
        Me.LabelOriginal.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelOriginal.Name = "LabelOriginal"
        Me.LabelOriginal.Size = New System.Drawing.Size(42, 13)
        Me.LabelOriginal.TabIndex = 2
        Me.LabelOriginal.Text = "Original"
        '
        'LabelEsperanto
        '
        Me.LabelEsperanto.AutoSize = True
        Me.LabelEsperanto.Location = New System.Drawing.Point(39, 193)
        Me.LabelEsperanto.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelEsperanto.Name = "LabelEsperanto"
        Me.LabelEsperanto.Size = New System.Drawing.Size(55, 13)
        Me.LabelEsperanto.TabIndex = 4
        Me.LabelEsperanto.Text = "Esperanto"
        '
        'RichTextBoxOriginal
        '
        Me.RichTextBoxOriginal.BackColor = System.Drawing.SystemColors.Window
        Me.RichTextBoxOriginal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBoxOriginal.Location = New System.Drawing.Point(41, 149)
        Me.RichTextBoxOriginal.Margin = New System.Windows.Forms.Padding(2)
        Me.RichTextBoxOriginal.Name = "RichTextBoxOriginal"
        Me.RichTextBoxOriginal.Size = New System.Drawing.Size(683, 43)
        Me.RichTextBoxOriginal.TabIndex = 3
        Me.RichTextBoxOriginal.Text = ""
        Me.ToolTip1.SetToolTip(Me.RichTextBoxOriginal, "Sentence in the Original Tag")
        '
        'RichTextBoxEsperanto
        '
        Me.RichTextBoxEsperanto.BackColor = System.Drawing.SystemColors.Window
        Me.RichTextBoxEsperanto.Font = New System.Drawing.Font("Orion Esperanto", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBoxEsperanto.Location = New System.Drawing.Point(41, 210)
        Me.RichTextBoxEsperanto.Margin = New System.Windows.Forms.Padding(2)
        Me.RichTextBoxEsperanto.Name = "RichTextBoxEsperanto"
        Me.RichTextBoxEsperanto.Size = New System.Drawing.Size(683, 44)
        Me.RichTextBoxEsperanto.TabIndex = 5
        Me.RichTextBoxEsperanto.Text = ""
        Me.ToolTip1.SetToolTip(Me.RichTextBoxEsperanto, "Result of Translation")
        '
        'ButtonTranslate
        '
        Me.ButtonTranslate.Location = New System.Drawing.Point(342, 34)
        Me.ButtonTranslate.Margin = New System.Windows.Forms.Padding(2)
        Me.ButtonTranslate.Name = "ButtonTranslate"
        Me.ButtonTranslate.Size = New System.Drawing.Size(124, 33)
        Me.ButtonTranslate.TabIndex = 1
        Me.ButtonTranslate.Text = "Übersetzen"
        Me.ToolTip1.SetToolTip(Me.ButtonTranslate, "Translate the loaded Sentence Grammar")
        Me.ButtonTranslate.UseVisualStyleBackColor = True
        '
        'LabelFehler
        '
        Me.LabelFehler.AutoSize = True
        Me.LabelFehler.Location = New System.Drawing.Point(39, 275)
        Me.LabelFehler.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelFehler.Name = "LabelFehler"
        Me.LabelFehler.Size = New System.Drawing.Size(76, 13)
        Me.LabelFehler.TabIndex = 6
        Me.LabelFehler.Text = "Fehlermeldung"
        '
        'TextBoxFehler
        '
        Me.TextBoxFehler.BackColor = System.Drawing.SystemColors.Window
        Me.TextBoxFehler.Location = New System.Drawing.Point(41, 291)
        Me.TextBoxFehler.Margin = New System.Windows.Forms.Padding(2)
        Me.TextBoxFehler.Name = "TextBoxFehler"
        Me.TextBoxFehler.Size = New System.Drawing.Size(683, 20)
        Me.TextBoxFehler.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.TextBoxFehler, "Hint for missing Vocabulary. You may add words to Vokabular.xml!")
        '
        'LabelFile
        '
        Me.LabelFile.AutoSize = True
        Me.LabelFile.Location = New System.Drawing.Point(39, 73)
        Me.LabelFile.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelFile.Name = "LabelFile"
        Me.LabelFile.Size = New System.Drawing.Size(32, 13)
        Me.LabelFile.TabIndex = 8
        Me.LabelFile.Text = "Datei"
        '
        'TextBoxFile
        '
        Me.TextBoxFile.BackColor = System.Drawing.SystemColors.Window
        Me.TextBoxFile.Location = New System.Drawing.Point(41, 89)
        Me.TextBoxFile.Margin = New System.Windows.Forms.Padding(2)
        Me.TextBoxFile.Name = "TextBoxFile"
        Me.TextBoxFile.Size = New System.Drawing.Size(683, 20)
        Me.TextBoxFile.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.TextBoxFile, "Loaded Sentence Grammar XML File")
        '
        'ComboBoxLanguage
        '
        Me.ComboBoxLanguage.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBoxLanguage.FormattingEnabled = True
        Me.ComboBoxLanguage.Location = New System.Drawing.Point(41, 34)
        Me.ComboBoxLanguage.Name = "ComboBoxLanguage"
        Me.ComboBoxLanguage.Size = New System.Drawing.Size(130, 23)
        Me.ComboBoxLanguage.TabIndex = 10
        Me.ToolTip1.SetToolTip(Me.ComboBoxLanguage, "Choose Language suitable for Sentence Grammar")
        '
        'TreeViewGrammatik
        '
        Me.TreeViewGrammatik.Location = New System.Drawing.Point(40, 343)
        Me.TreeViewGrammatik.Name = "TreeViewGrammatik"
        Me.TreeViewGrammatik.Size = New System.Drawing.Size(327, 334)
        Me.TreeViewGrammatik.TabIndex = 12
        Me.ToolTip2.SetToolTip(Me.TreeViewGrammatik, "Sentence Grammar Structure. Click on an Element to edit it on the right side! Ope" & _
                "n the branches via clicking the plus signs.")
        '
        'LabelTreeView
        '
        Me.LabelTreeView.AutoSize = True
        Me.LabelTreeView.Location = New System.Drawing.Point(42, 323)
        Me.LabelTreeView.Name = "LabelTreeView"
        Me.LabelTreeView.Size = New System.Drawing.Size(55, 13)
        Me.LabelTreeView.TabIndex = 11
        Me.LabelTreeView.Text = "Tree View"
        '
        'LabelEdit
        '
        Me.LabelEdit.AutoSize = True
        Me.LabelEdit.Location = New System.Drawing.Point(427, 323)
        Me.LabelEdit.Name = "LabelEdit"
        Me.LabelEdit.Size = New System.Drawing.Size(25, 13)
        Me.LabelEdit.TabIndex = 13
        Me.LabelEdit.Text = "Edit"
        '
        'LabelEditElement
        '
        Me.LabelEditElement.AutoSize = True
        Me.LabelEditElement.Location = New System.Drawing.Point(427, 355)
        Me.LabelEditElement.Name = "LabelEditElement"
        Me.LabelEditElement.Size = New System.Drawing.Size(63, 13)
        Me.LabelEditElement.TabIndex = 14
        Me.LabelEditElement.Text = "EditElement"
        '
        'LabelProperty1
        '
        Me.LabelProperty1.AutoSize = True
        Me.LabelProperty1.Location = New System.Drawing.Point(427, 391)
        Me.LabelProperty1.Name = "LabelProperty1"
        Me.LabelProperty1.Size = New System.Drawing.Size(52, 13)
        Me.LabelProperty1.TabIndex = 15
        Me.LabelProperty1.Text = "Property1"
        '
        'LabelProperty2
        '
        Me.LabelProperty2.AutoSize = True
        Me.LabelProperty2.Location = New System.Drawing.Point(427, 426)
        Me.LabelProperty2.Name = "LabelProperty2"
        Me.LabelProperty2.Size = New System.Drawing.Size(52, 13)
        Me.LabelProperty2.TabIndex = 16
        Me.LabelProperty2.Text = "Property2"
        '
        'LabelProperty3
        '
        Me.LabelProperty3.AutoSize = True
        Me.LabelProperty3.Location = New System.Drawing.Point(427, 463)
        Me.LabelProperty3.Name = "LabelProperty3"
        Me.LabelProperty3.Size = New System.Drawing.Size(52, 13)
        Me.LabelProperty3.TabIndex = 17
        Me.LabelProperty3.Text = "Property3"
        '
        'LabelProperty4
        '
        Me.LabelProperty4.AutoSize = True
        Me.LabelProperty4.Location = New System.Drawing.Point(427, 499)
        Me.LabelProperty4.Name = "LabelProperty4"
        Me.LabelProperty4.Size = New System.Drawing.Size(52, 13)
        Me.LabelProperty4.TabIndex = 18
        Me.LabelProperty4.Text = "Property4"
        '
        'LabelProperty5
        '
        Me.LabelProperty5.AutoSize = True
        Me.LabelProperty5.Location = New System.Drawing.Point(426, 535)
        Me.LabelProperty5.Name = "LabelProperty5"
        Me.LabelProperty5.Size = New System.Drawing.Size(52, 13)
        Me.LabelProperty5.TabIndex = 19
        Me.LabelProperty5.Text = "Property5"
        '
        'LabelProperty6
        '
        Me.LabelProperty6.AutoSize = True
        Me.LabelProperty6.Location = New System.Drawing.Point(426, 571)
        Me.LabelProperty6.Name = "LabelProperty6"
        Me.LabelProperty6.Size = New System.Drawing.Size(52, 13)
        Me.LabelProperty6.TabIndex = 20
        Me.LabelProperty6.Text = "Property6"
        '
        'LabelProperty7
        '
        Me.LabelProperty7.AutoSize = True
        Me.LabelProperty7.Location = New System.Drawing.Point(426, 606)
        Me.LabelProperty7.Name = "LabelProperty7"
        Me.LabelProperty7.Size = New System.Drawing.Size(52, 13)
        Me.LabelProperty7.TabIndex = 21
        Me.LabelProperty7.Text = "Property7"
        '
        'ComboBoxProperty1
        '
        Me.ComboBoxProperty1.FormattingEnabled = True
        Me.ComboBoxProperty1.Location = New System.Drawing.Point(551, 388)
        Me.ComboBoxProperty1.Name = "ComboBoxProperty1"
        Me.ComboBoxProperty1.Size = New System.Drawing.Size(122, 21)
        Me.ComboBoxProperty1.TabIndex = 22
        Me.ToolTip2.SetToolTip(Me.ComboBoxProperty1, "Select Option")
        '
        'ComboBoxProperty2
        '
        Me.ComboBoxProperty2.FormattingEnabled = True
        Me.ComboBoxProperty2.Location = New System.Drawing.Point(551, 423)
        Me.ComboBoxProperty2.Name = "ComboBoxProperty2"
        Me.ComboBoxProperty2.Size = New System.Drawing.Size(122, 21)
        Me.ComboBoxProperty2.TabIndex = 23
        Me.ToolTip2.SetToolTip(Me.ComboBoxProperty2, "Select Option")
        '
        'ComboBoxProperty3
        '
        Me.ComboBoxProperty3.FormattingEnabled = True
        Me.ComboBoxProperty3.Location = New System.Drawing.Point(551, 460)
        Me.ComboBoxProperty3.Name = "ComboBoxProperty3"
        Me.ComboBoxProperty3.Size = New System.Drawing.Size(122, 21)
        Me.ComboBoxProperty3.TabIndex = 24
        Me.ToolTip2.SetToolTip(Me.ComboBoxProperty3, "Select Option")
        '
        'ComboBoxProperty4
        '
        Me.ComboBoxProperty4.FormattingEnabled = True
        Me.ComboBoxProperty4.Location = New System.Drawing.Point(551, 496)
        Me.ComboBoxProperty4.Name = "ComboBoxProperty4"
        Me.ComboBoxProperty4.Size = New System.Drawing.Size(122, 21)
        Me.ComboBoxProperty4.TabIndex = 25
        Me.ToolTip2.SetToolTip(Me.ComboBoxProperty4, "Select Option")
        '
        'ComboBoxProperty5
        '
        Me.ComboBoxProperty5.FormattingEnabled = True
        Me.ComboBoxProperty5.Location = New System.Drawing.Point(551, 531)
        Me.ComboBoxProperty5.Name = "ComboBoxProperty5"
        Me.ComboBoxProperty5.Size = New System.Drawing.Size(122, 21)
        Me.ComboBoxProperty5.TabIndex = 26
        Me.ToolTip2.SetToolTip(Me.ComboBoxProperty5, "Select Option")
        '
        'ComboBoxProperty6
        '
        Me.ComboBoxProperty6.FormattingEnabled = True
        Me.ComboBoxProperty6.Location = New System.Drawing.Point(551, 568)
        Me.ComboBoxProperty6.Name = "ComboBoxProperty6"
        Me.ComboBoxProperty6.Size = New System.Drawing.Size(122, 21)
        Me.ComboBoxProperty6.TabIndex = 27
        Me.ToolTip2.SetToolTip(Me.ComboBoxProperty6, "Select Option")
        '
        'ComboBoxProperty7
        '
        Me.ComboBoxProperty7.FormattingEnabled = True
        Me.ComboBoxProperty7.Location = New System.Drawing.Point(551, 603)
        Me.ComboBoxProperty7.Name = "ComboBoxProperty7"
        Me.ComboBoxProperty7.Size = New System.Drawing.Size(122, 21)
        Me.ComboBoxProperty7.TabIndex = 28
        Me.ToolTip2.SetToolTip(Me.ComboBoxProperty7, "Select Option")
        '
        'ButtonSaveEdit
        '
        Me.ButtonSaveEdit.Location = New System.Drawing.Point(551, 651)
        Me.ButtonSaveEdit.Name = "ButtonSaveEdit"
        Me.ButtonSaveEdit.Size = New System.Drawing.Size(122, 26)
        Me.ButtonSaveEdit.TabIndex = 29
        Me.ButtonSaveEdit.Text = "Save Edit"
        Me.ToolTip2.SetToolTip(Me.ButtonSaveEdit, "Save edited Element. Changes are directly accessible in the Translation Pane abov" & _
                "e. Dont forget to change also the Original Sentence!")
        Me.ButtonSaveEdit.UseVisualStyleBackColor = True
        '
        'TextBoxEditElement
        '
        Me.TextBoxEditElement.Location = New System.Drawing.Point(551, 352)
        Me.TextBoxEditElement.Name = "TextBoxEditElement"
        Me.TextBoxEditElement.Size = New System.Drawing.Size(122, 20)
        Me.TextBoxEditElement.TabIndex = 30
        Me.ToolTip2.SetToolTip(Me.TextBoxEditElement, "Edit textual Element")
        '
        'ButtonSaveXML
        '
        Me.ButtonSaveXML.Location = New System.Drawing.Point(483, 27)
        Me.ButtonSaveXML.Name = "ButtonSaveXML"
        Me.ButtonSaveXML.Size = New System.Drawing.Size(120, 46)
        Me.ButtonSaveXML.TabIndex = 31
        Me.ButtonSaveXML.Text = "XML-Grammatik speichern ..."
        Me.ToolTip1.SetToolTip(Me.ButtonSaveXML, "Save modified Sentence Grammar")
        Me.ButtonSaveXML.UseVisualStyleBackColor = True
        '
        'ButtonHelp
        '
        Me.ButtonHelp.BackColor = System.Drawing.SystemColors.Info
        Me.ButtonHelp.Location = New System.Drawing.Point(430, 639)
        Me.ButtonHelp.Name = "ButtonHelp"
        Me.ButtonHelp.Size = New System.Drawing.Size(64, 38)
        Me.ButtonHelp.TabIndex = 32
        Me.ButtonHelp.Text = "Help"
        Me.ToolTip2.SetToolTip(Me.ButtonHelp, "Get Help from the HTML Help File")
        Me.ButtonHelp.UseVisualStyleBackColor = False
        '
        'ToolTip1
        '
        Me.ToolTip1.ToolTipTitle = "Translation Pane"
        '
        'ButtonDictionary
        '
        Me.ButtonDictionary.Location = New System.Drawing.Point(633, 27)
        Me.ButtonDictionary.Name = "ButtonDictionary"
        Me.ButtonDictionary.Size = New System.Drawing.Size(91, 23)
        Me.ButtonDictionary.TabIndex = 33
        Me.ButtonDictionary.Text = "Dictionary"
        Me.ToolTip1.SetToolTip(Me.ButtonDictionary, "Any to Any Dictionary")
        Me.ButtonDictionary.UseVisualStyleBackColor = True
        '
        'ToolTip2
        '
        Me.ToolTip2.ToolTipTitle = "Edit Pane"
        '
        'ButtonTrainer
        '
        Me.ButtonTrainer.Location = New System.Drawing.Point(633, 50)
        Me.ButtonTrainer.Name = "ButtonTrainer"
        Me.ButtonTrainer.Size = New System.Drawing.Size(91, 23)
        Me.ButtonTrainer.TabIndex = 34
        Me.ButtonTrainer.Text = "Trainer"
        Me.ToolTip1.SetToolTip(Me.ButtonTrainer, "Vocabulary Trainer")
        Me.ButtonTrainer.UseVisualStyleBackColor = True
        '
        'Decaleon
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(768, 710)
        Me.Controls.Add(Me.ButtonTrainer)
        Me.Controls.Add(Me.ButtonDictionary)
        Me.Controls.Add(Me.ButtonHelp)
        Me.Controls.Add(Me.ButtonSaveXML)
        Me.Controls.Add(Me.TextBoxEditElement)
        Me.Controls.Add(Me.ButtonSaveEdit)
        Me.Controls.Add(Me.ComboBoxProperty7)
        Me.Controls.Add(Me.ComboBoxProperty6)
        Me.Controls.Add(Me.ComboBoxProperty5)
        Me.Controls.Add(Me.ComboBoxProperty4)
        Me.Controls.Add(Me.ComboBoxProperty3)
        Me.Controls.Add(Me.ComboBoxProperty2)
        Me.Controls.Add(Me.ComboBoxProperty1)
        Me.Controls.Add(Me.LabelProperty7)
        Me.Controls.Add(Me.LabelProperty6)
        Me.Controls.Add(Me.LabelProperty5)
        Me.Controls.Add(Me.LabelProperty4)
        Me.Controls.Add(Me.LabelProperty3)
        Me.Controls.Add(Me.LabelProperty2)
        Me.Controls.Add(Me.LabelProperty1)
        Me.Controls.Add(Me.LabelEditElement)
        Me.Controls.Add(Me.LabelEdit)
        Me.Controls.Add(Me.LabelTreeView)
        Me.Controls.Add(Me.TreeViewGrammatik)
        Me.Controls.Add(Me.ComboBoxLanguage)
        Me.Controls.Add(Me.TextBoxFile)
        Me.Controls.Add(Me.LabelFile)
        Me.Controls.Add(Me.TextBoxFehler)
        Me.Controls.Add(Me.LabelFehler)
        Me.Controls.Add(Me.ButtonTranslate)
        Me.Controls.Add(Me.RichTextBoxEsperanto)
        Me.Controls.Add(Me.RichTextBoxOriginal)
        Me.Controls.Add(Me.LabelEsperanto)
        Me.Controls.Add(Me.LabelOriginal)
        Me.Controls.Add(Me.ButtonLoadXML)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "Decaleon"
        Me.Text = "Esperanto - Translator  V3.0"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ButtonLoadXML As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents LabelOriginal As System.Windows.Forms.Label
    Friend WithEvents LabelEsperanto As System.Windows.Forms.Label
    Friend WithEvents RichTextBoxOriginal As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBoxEsperanto As System.Windows.Forms.RichTextBox
    Friend WithEvents ButtonTranslate As System.Windows.Forms.Button
    Friend WithEvents LabelFehler As System.Windows.Forms.Label
    Friend WithEvents TextBoxFehler As System.Windows.Forms.TextBox
    Friend WithEvents LabelFile As System.Windows.Forms.Label
    Friend WithEvents TextBoxFile As System.Windows.Forms.TextBox
    Friend WithEvents ComboBoxLanguage As System.Windows.Forms.ComboBox
    Friend WithEvents TreeViewGrammatik As System.Windows.Forms.TreeView
    Friend WithEvents LabelTreeView As System.Windows.Forms.Label
    Friend WithEvents LabelEdit As System.Windows.Forms.Label
    Friend WithEvents LabelEditElement As System.Windows.Forms.Label
    Friend WithEvents LabelProperty1 As System.Windows.Forms.Label
    Friend WithEvents LabelProperty2 As System.Windows.Forms.Label
    Friend WithEvents LabelProperty3 As System.Windows.Forms.Label
    Friend WithEvents LabelProperty4 As System.Windows.Forms.Label
    Friend WithEvents LabelProperty5 As System.Windows.Forms.Label
    Friend WithEvents LabelProperty6 As System.Windows.Forms.Label
    Friend WithEvents LabelProperty7 As System.Windows.Forms.Label
    Friend WithEvents ComboBoxProperty1 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxProperty2 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxProperty3 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxProperty4 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxProperty5 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxProperty6 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxProperty7 As System.Windows.Forms.ComboBox
    Friend WithEvents ButtonSaveEdit As System.Windows.Forms.Button
    Friend WithEvents TextBoxEditElement As System.Windows.Forms.TextBox
    Friend WithEvents ButtonSaveXML As System.Windows.Forms.Button
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents ButtonHelp As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents ToolTip2 As System.Windows.Forms.ToolTip
    Friend WithEvents ButtonDictionary As System.Windows.Forms.Button
    Friend WithEvents ButtonTrainer As System.Windows.Forms.Button

End Class
