﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FDictionary
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LabelFrom = New System.Windows.Forms.Label()
        Me.ComboBoxFrom = New System.Windows.Forms.ComboBox()
        Me.LabelTo = New System.Windows.Forms.Label()
        Me.ComboBoxTo = New System.Windows.Forms.ComboBox()
        Me.LabelWord = New System.Windows.Forms.Label()
        Me.TextBoxWord = New System.Windows.Forms.TextBox()
        Me.ButtonSearch = New System.Windows.Forms.Button()
        Me.LabelTranslation = New System.Windows.Forms.Label()
        Me.RichTextBoxTranslation = New System.Windows.Forms.RichTextBox()
        Me.ButtonOK = New System.Windows.Forms.Button()
        Me.GroupBoxMode = New System.Windows.Forms.GroupBox()
        Me.RadioButtonStart = New System.Windows.Forms.RadioButton()
        Me.RadioButtonStrict = New System.Windows.Forms.RadioButton()
        Me.GroupBoxSingleWord = New System.Windows.Forms.GroupBox()
        Me.GroupBoxWordList = New System.Windows.Forms.GroupBox()
        Me.GroupBoxOutput = New System.Windows.Forms.GroupBox()
        Me.RadioButtonUnicode = New System.Windows.Forms.RadioButton()
        Me.RadioButtonHtml = New System.Windows.Forms.RadioButton()
        Me.ComboBoxTo2 = New System.Windows.Forms.ComboBox()
        Me.LabelTo2 = New System.Windows.Forms.Label()
        Me.ComboBoxFrom2 = New System.Windows.Forms.ComboBox()
        Me.LabelFrom2 = New System.Windows.Forms.Label()
        Me.ButtonList = New System.Windows.Forms.Button()
        Me.ComboBoxSortChoice = New System.Windows.Forms.ComboBox()
        Me.GroupBoxCriterion = New System.Windows.Forms.GroupBox()
        Me.RadioButtonTheme = New System.Windows.Forms.RadioButton()
        Me.RadioButtonNiveau = New System.Windows.Forms.RadioButton()
        Me.GroupBoxDictionary = New System.Windows.Forms.GroupBox()
        Me.LabelDictionaryStatus = New System.Windows.Forms.Label()
        Me.GroupBoxDictType = New System.Windows.Forms.GroupBox()
        Me.RadioButtonLexikon = New System.Windows.Forms.RadioButton()
        Me.RadioButtonDict = New System.Windows.Forms.RadioButton()
        Me.GroupBoxFormat = New System.Windows.Forms.GroupBox()
        Me.RadioButtonPDF = New System.Windows.Forms.RadioButton()
        Me.RadioButtonLatex = New System.Windows.Forms.RadioButton()
        Me.ComboBoxTo3 = New System.Windows.Forms.ComboBox()
        Me.LabelTo3 = New System.Windows.Forms.Label()
        Me.ComboBoxFrom3 = New System.Windows.Forms.ComboBox()
        Me.LabelFrom3 = New System.Windows.Forms.Label()
        Me.ButtonDict = New System.Windows.Forms.Button()
        Me.GroupBoxMode.SuspendLayout()
        Me.GroupBoxSingleWord.SuspendLayout()
        Me.GroupBoxWordList.SuspendLayout()
        Me.GroupBoxOutput.SuspendLayout()
        Me.GroupBoxCriterion.SuspendLayout()
        Me.GroupBoxDictionary.SuspendLayout()
        Me.GroupBoxDictType.SuspendLayout()
        Me.GroupBoxFormat.SuspendLayout()
        Me.SuspendLayout()
        '
        'LabelFrom
        '
        Me.LabelFrom.AutoSize = True
        Me.LabelFrom.Location = New System.Drawing.Point(12, 17)
        Me.LabelFrom.Name = "LabelFrom"
        Me.LabelFrom.Size = New System.Drawing.Size(25, 13)
        Me.LabelFrom.TabIndex = 1
        Me.LabelFrom.Text = "von"
        '
        'ComboBoxFrom
        '
        Me.ComboBoxFrom.FormattingEnabled = True
        Me.ComboBoxFrom.Location = New System.Drawing.Point(15, 33)
        Me.ComboBoxFrom.Name = "ComboBoxFrom"
        Me.ComboBoxFrom.Size = New System.Drawing.Size(130, 21)
        Me.ComboBoxFrom.TabIndex = 2
        '
        'LabelTo
        '
        Me.LabelTo.AutoSize = True
        Me.LabelTo.Location = New System.Drawing.Point(188, 17)
        Me.LabelTo.Name = "LabelTo"
        Me.LabelTo.Size = New System.Drawing.Size(31, 13)
        Me.LabelTo.TabIndex = 3
        Me.LabelTo.Text = "nach"
        '
        'ComboBoxTo
        '
        Me.ComboBoxTo.FormattingEnabled = True
        Me.ComboBoxTo.Location = New System.Drawing.Point(191, 33)
        Me.ComboBoxTo.Name = "ComboBoxTo"
        Me.ComboBoxTo.Size = New System.Drawing.Size(130, 21)
        Me.ComboBoxTo.TabIndex = 4
        '
        'LabelWord
        '
        Me.LabelWord.AutoSize = True
        Me.LabelWord.Location = New System.Drawing.Point(12, 67)
        Me.LabelWord.Name = "LabelWord"
        Me.LabelWord.Size = New System.Drawing.Size(30, 13)
        Me.LabelWord.TabIndex = 5
        Me.LabelWord.Text = "Wort"
        '
        'TextBoxWord
        '
        Me.TextBoxWord.Location = New System.Drawing.Point(15, 83)
        Me.TextBoxWord.Name = "TextBoxWord"
        Me.TextBoxWord.Size = New System.Drawing.Size(155, 20)
        Me.TextBoxWord.TabIndex = 6
        '
        'ButtonSearch
        '
        Me.ButtonSearch.Location = New System.Drawing.Point(51, 180)
        Me.ButtonSearch.Name = "ButtonSearch"
        Me.ButtonSearch.Size = New System.Drawing.Size(69, 28)
        Me.ButtonSearch.TabIndex = 0
        Me.ButtonSearch.Text = "Suche"
        Me.ButtonSearch.UseVisualStyleBackColor = True
        '
        'LabelTranslation
        '
        Me.LabelTranslation.AutoSize = True
        Me.LabelTranslation.Location = New System.Drawing.Point(188, 67)
        Me.LabelTranslation.Name = "LabelTranslation"
        Me.LabelTranslation.Size = New System.Drawing.Size(67, 13)
        Me.LabelTranslation.TabIndex = 7
        Me.LabelTranslation.Text = "Übersetzung"
        '
        'RichTextBoxTranslation
        '
        Me.RichTextBoxTranslation.Location = New System.Drawing.Point(191, 83)
        Me.RichTextBoxTranslation.Name = "RichTextBoxTranslation"
        Me.RichTextBoxTranslation.Size = New System.Drawing.Size(183, 174)
        Me.RichTextBoxTranslation.TabIndex = 8
        Me.RichTextBoxTranslation.Text = ""
        '
        'ButtonOK
        '
        Me.ButtonOK.Location = New System.Drawing.Point(320, 642)
        Me.ButtonOK.Name = "ButtonOK"
        Me.ButtonOK.Size = New System.Drawing.Size(69, 28)
        Me.ButtonOK.TabIndex = 9
        Me.ButtonOK.Text = "OK"
        Me.ButtonOK.UseVisualStyleBackColor = True
        '
        'GroupBoxMode
        '
        Me.GroupBoxMode.Controls.Add(Me.RadioButtonStart)
        Me.GroupBoxMode.Controls.Add(Me.RadioButtonStrict)
        Me.GroupBoxMode.Location = New System.Drawing.Point(15, 121)
        Me.GroupBoxMode.Name = "GroupBoxMode"
        Me.GroupBoxMode.Size = New System.Drawing.Size(155, 42)
        Me.GroupBoxMode.TabIndex = 10
        Me.GroupBoxMode.TabStop = False
        Me.GroupBoxMode.Text = "Suchmodus"
        '
        'RadioButtonStart
        '
        Me.RadioButtonStart.AutoSize = True
        Me.RadioButtonStart.Location = New System.Drawing.Point(68, 15)
        Me.RadioButtonStart.Name = "RadioButtonStart"
        Me.RadioButtonStart.Size = New System.Drawing.Size(81, 17)
        Me.RadioButtonStart.TabIndex = 1
        Me.RadioButtonStart.TabStop = True
        Me.RadioButtonStart.Text = "Wortanfang"
        Me.RadioButtonStart.UseVisualStyleBackColor = True
        '
        'RadioButtonStrict
        '
        Me.RadioButtonStrict.AutoSize = True
        Me.RadioButtonStrict.Location = New System.Drawing.Point(6, 15)
        Me.RadioButtonStrict.Name = "RadioButtonStrict"
        Me.RadioButtonStrict.Size = New System.Drawing.Size(54, 17)
        Me.RadioButtonStrict.TabIndex = 0
        Me.RadioButtonStrict.TabStop = True
        Me.RadioButtonStrict.Text = "streng"
        Me.RadioButtonStrict.UseVisualStyleBackColor = True
        '
        'GroupBoxSingleWord
        '
        Me.GroupBoxSingleWord.Controls.Add(Me.GroupBoxMode)
        Me.GroupBoxSingleWord.Controls.Add(Me.RichTextBoxTranslation)
        Me.GroupBoxSingleWord.Controls.Add(Me.LabelTranslation)
        Me.GroupBoxSingleWord.Controls.Add(Me.ButtonSearch)
        Me.GroupBoxSingleWord.Controls.Add(Me.TextBoxWord)
        Me.GroupBoxSingleWord.Controls.Add(Me.LabelWord)
        Me.GroupBoxSingleWord.Controls.Add(Me.ComboBoxTo)
        Me.GroupBoxSingleWord.Controls.Add(Me.LabelTo)
        Me.GroupBoxSingleWord.Controls.Add(Me.ComboBoxFrom)
        Me.GroupBoxSingleWord.Controls.Add(Me.LabelFrom)
        Me.GroupBoxSingleWord.Location = New System.Drawing.Point(16, 12)
        Me.GroupBoxSingleWord.Name = "GroupBoxSingleWord"
        Me.GroupBoxSingleWord.Size = New System.Drawing.Size(388, 274)
        Me.GroupBoxSingleWord.TabIndex = 11
        Me.GroupBoxSingleWord.TabStop = False
        Me.GroupBoxSingleWord.Text = "Wortsuche"
        '
        'GroupBoxWordList
        '
        Me.GroupBoxWordList.Controls.Add(Me.GroupBoxOutput)
        Me.GroupBoxWordList.Controls.Add(Me.ComboBoxTo2)
        Me.GroupBoxWordList.Controls.Add(Me.LabelTo2)
        Me.GroupBoxWordList.Controls.Add(Me.ComboBoxFrom2)
        Me.GroupBoxWordList.Controls.Add(Me.LabelFrom2)
        Me.GroupBoxWordList.Controls.Add(Me.ButtonList)
        Me.GroupBoxWordList.Controls.Add(Me.ComboBoxSortChoice)
        Me.GroupBoxWordList.Controls.Add(Me.GroupBoxCriterion)
        Me.GroupBoxWordList.Location = New System.Drawing.Point(16, 298)
        Me.GroupBoxWordList.Name = "GroupBoxWordList"
        Me.GroupBoxWordList.Size = New System.Drawing.Size(388, 161)
        Me.GroupBoxWordList.TabIndex = 12
        Me.GroupBoxWordList.TabStop = False
        Me.GroupBoxWordList.Text = "Vokabelliste"
        '
        'GroupBoxOutput
        '
        Me.GroupBoxOutput.Controls.Add(Me.RadioButtonUnicode)
        Me.GroupBoxOutput.Controls.Add(Me.RadioButtonHtml)
        Me.GroupBoxOutput.Location = New System.Drawing.Point(191, 68)
        Me.GroupBoxOutput.Name = "GroupBoxOutput"
        Me.GroupBoxOutput.Size = New System.Drawing.Size(155, 42)
        Me.GroupBoxOutput.TabIndex = 7
        Me.GroupBoxOutput.TabStop = False
        Me.GroupBoxOutput.Text = "Ausgabeformat"
        '
        'RadioButtonUnicode
        '
        Me.RadioButtonUnicode.AutoSize = True
        Me.RadioButtonUnicode.Location = New System.Drawing.Point(71, 16)
        Me.RadioButtonUnicode.Name = "RadioButtonUnicode"
        Me.RadioButtonUnicode.Size = New System.Drawing.Size(65, 17)
        Me.RadioButtonUnicode.TabIndex = 1
        Me.RadioButtonUnicode.TabStop = True
        Me.RadioButtonUnicode.Text = "Unicode"
        Me.RadioButtonUnicode.UseVisualStyleBackColor = True
        '
        'RadioButtonHtml
        '
        Me.RadioButtonHtml.AutoSize = True
        Me.RadioButtonHtml.Location = New System.Drawing.Point(6, 16)
        Me.RadioButtonHtml.Name = "RadioButtonHtml"
        Me.RadioButtonHtml.Size = New System.Drawing.Size(55, 17)
        Me.RadioButtonHtml.TabIndex = 0
        Me.RadioButtonHtml.TabStop = True
        Me.RadioButtonHtml.Text = "HTML"
        Me.RadioButtonHtml.UseVisualStyleBackColor = True
        '
        'ComboBoxTo2
        '
        Me.ComboBoxTo2.FormattingEnabled = True
        Me.ComboBoxTo2.Location = New System.Drawing.Point(191, 33)
        Me.ComboBoxTo2.Name = "ComboBoxTo2"
        Me.ComboBoxTo2.Size = New System.Drawing.Size(130, 21)
        Me.ComboBoxTo2.TabIndex = 4
        '
        'LabelTo2
        '
        Me.LabelTo2.AutoSize = True
        Me.LabelTo2.Location = New System.Drawing.Point(188, 17)
        Me.LabelTo2.Name = "LabelTo2"
        Me.LabelTo2.Size = New System.Drawing.Size(31, 13)
        Me.LabelTo2.TabIndex = 3
        Me.LabelTo2.Text = "nach"
        '
        'ComboBoxFrom2
        '
        Me.ComboBoxFrom2.FormattingEnabled = True
        Me.ComboBoxFrom2.Location = New System.Drawing.Point(15, 33)
        Me.ComboBoxFrom2.Name = "ComboBoxFrom2"
        Me.ComboBoxFrom2.Size = New System.Drawing.Size(130, 21)
        Me.ComboBoxFrom2.TabIndex = 2
        '
        'LabelFrom2
        '
        Me.LabelFrom2.AutoSize = True
        Me.LabelFrom2.Location = New System.Drawing.Point(12, 17)
        Me.LabelFrom2.Name = "LabelFrom2"
        Me.LabelFrom2.Size = New System.Drawing.Size(25, 13)
        Me.LabelFrom2.TabIndex = 1
        Me.LabelFrom2.Text = "von"
        '
        'ButtonList
        '
        Me.ButtonList.Location = New System.Drawing.Point(304, 121)
        Me.ButtonList.Name = "ButtonList"
        Me.ButtonList.Size = New System.Drawing.Size(69, 28)
        Me.ButtonList.TabIndex = 0
        Me.ButtonList.Text = "Liste"
        Me.ButtonList.UseVisualStyleBackColor = True
        '
        'ComboBoxSortChoice
        '
        Me.ComboBoxSortChoice.FormattingEnabled = True
        Me.ComboBoxSortChoice.Location = New System.Drawing.Point(15, 126)
        Me.ComboBoxSortChoice.Name = "ComboBoxSortChoice"
        Me.ComboBoxSortChoice.Size = New System.Drawing.Size(272, 21)
        Me.ComboBoxSortChoice.TabIndex = 6
        '
        'GroupBoxCriterion
        '
        Me.GroupBoxCriterion.Controls.Add(Me.RadioButtonTheme)
        Me.GroupBoxCriterion.Controls.Add(Me.RadioButtonNiveau)
        Me.GroupBoxCriterion.Location = New System.Drawing.Point(15, 68)
        Me.GroupBoxCriterion.Name = "GroupBoxCriterion"
        Me.GroupBoxCriterion.Size = New System.Drawing.Size(155, 42)
        Me.GroupBoxCriterion.TabIndex = 5
        Me.GroupBoxCriterion.TabStop = False
        Me.GroupBoxCriterion.Text = "Auswahlkriterium"
        '
        'RadioButtonTheme
        '
        Me.RadioButtonTheme.AutoSize = True
        Me.RadioButtonTheme.Location = New System.Drawing.Point(71, 16)
        Me.RadioButtonTheme.Name = "RadioButtonTheme"
        Me.RadioButtonTheme.Size = New System.Drawing.Size(58, 17)
        Me.RadioButtonTheme.TabIndex = 1
        Me.RadioButtonTheme.TabStop = True
        Me.RadioButtonTheme.Text = "Thema"
        Me.RadioButtonTheme.UseVisualStyleBackColor = True
        '
        'RadioButtonNiveau
        '
        Me.RadioButtonNiveau.AutoSize = True
        Me.RadioButtonNiveau.Location = New System.Drawing.Point(6, 16)
        Me.RadioButtonNiveau.Name = "RadioButtonNiveau"
        Me.RadioButtonNiveau.Size = New System.Drawing.Size(59, 17)
        Me.RadioButtonNiveau.TabIndex = 0
        Me.RadioButtonNiveau.TabStop = True
        Me.RadioButtonNiveau.Text = "Niveau"
        Me.RadioButtonNiveau.UseVisualStyleBackColor = True
        '
        'GroupBoxDictionary
        '
        Me.GroupBoxDictionary.Controls.Add(Me.LabelDictionaryStatus)
        Me.GroupBoxDictionary.Controls.Add(Me.GroupBoxDictType)
        Me.GroupBoxDictionary.Controls.Add(Me.GroupBoxFormat)
        Me.GroupBoxDictionary.Controls.Add(Me.ComboBoxTo3)
        Me.GroupBoxDictionary.Controls.Add(Me.LabelTo3)
        Me.GroupBoxDictionary.Controls.Add(Me.ComboBoxFrom3)
        Me.GroupBoxDictionary.Controls.Add(Me.LabelFrom3)
        Me.GroupBoxDictionary.Controls.Add(Me.ButtonDict)
        Me.GroupBoxDictionary.Location = New System.Drawing.Point(16, 471)
        Me.GroupBoxDictionary.Name = "GroupBoxDictionary"
        Me.GroupBoxDictionary.Size = New System.Drawing.Size(388, 161)
        Me.GroupBoxDictionary.TabIndex = 13
        Me.GroupBoxDictionary.TabStop = False
        Me.GroupBoxDictionary.Text = "Wörterbuch"
        '
        'LabelDictionaryStatus
        '
        Me.LabelDictionaryStatus.AutoSize = True
        Me.LabelDictionaryStatus.Location = New System.Drawing.Point(21, 126)
        Me.LabelDictionaryStatus.Name = "LabelDictionaryStatus"
        Me.LabelDictionaryStatus.Size = New System.Drawing.Size(37, 13)
        Me.LabelDictionaryStatus.TabIndex = 7
        Me.LabelDictionaryStatus.Text = "Status"
        '
        'GroupBoxDictType
        '
        Me.GroupBoxDictType.Controls.Add(Me.RadioButtonLexikon)
        Me.GroupBoxDictType.Controls.Add(Me.RadioButtonDict)
        Me.GroupBoxDictType.Location = New System.Drawing.Point(191, 62)
        Me.GroupBoxDictType.Name = "GroupBoxDictType"
        Me.GroupBoxDictType.Size = New System.Drawing.Size(155, 42)
        Me.GroupBoxDictType.TabIndex = 6
        Me.GroupBoxDictType.TabStop = False
        Me.GroupBoxDictType.Text = "Dictionary-Type"
        '
        'RadioButtonLexikon
        '
        Me.RadioButtonLexikon.AutoSize = True
        Me.RadioButtonLexikon.Location = New System.Drawing.Point(71, 16)
        Me.RadioButtonLexikon.Name = "RadioButtonLexikon"
        Me.RadioButtonLexikon.Size = New System.Drawing.Size(69, 17)
        Me.RadioButtonLexikon.TabIndex = 1
        Me.RadioButtonLexikon.TabStop = True
        Me.RadioButtonLexikon.Text = "Thematic"
        Me.RadioButtonLexikon.UseVisualStyleBackColor = True
        '
        'RadioButtonDict
        '
        Me.RadioButtonDict.AutoSize = True
        Me.RadioButtonDict.Location = New System.Drawing.Point(6, 16)
        Me.RadioButtonDict.Name = "RadioButtonDict"
        Me.RadioButtonDict.Size = New System.Drawing.Size(58, 17)
        Me.RadioButtonDict.TabIndex = 0
        Me.RadioButtonDict.TabStop = True
        Me.RadioButtonDict.Text = "Lexical"
        Me.RadioButtonDict.UseVisualStyleBackColor = True
        '
        'GroupBoxFormat
        '
        Me.GroupBoxFormat.Controls.Add(Me.RadioButtonPDF)
        Me.GroupBoxFormat.Controls.Add(Me.RadioButtonLatex)
        Me.GroupBoxFormat.Location = New System.Drawing.Point(15, 62)
        Me.GroupBoxFormat.Name = "GroupBoxFormat"
        Me.GroupBoxFormat.Size = New System.Drawing.Size(155, 42)
        Me.GroupBoxFormat.TabIndex = 5
        Me.GroupBoxFormat.TabStop = False
        Me.GroupBoxFormat.Text = "Ausgabeformat"
        '
        'RadioButtonPDF
        '
        Me.RadioButtonPDF.AutoSize = True
        Me.RadioButtonPDF.Location = New System.Drawing.Point(71, 16)
        Me.RadioButtonPDF.Name = "RadioButtonPDF"
        Me.RadioButtonPDF.Size = New System.Drawing.Size(46, 17)
        Me.RadioButtonPDF.TabIndex = 1
        Me.RadioButtonPDF.TabStop = True
        Me.RadioButtonPDF.Text = "PDF"
        Me.RadioButtonPDF.UseVisualStyleBackColor = True
        '
        'RadioButtonLatex
        '
        Me.RadioButtonLatex.AutoSize = True
        Me.RadioButtonLatex.Location = New System.Drawing.Point(6, 16)
        Me.RadioButtonLatex.Name = "RadioButtonLatex"
        Me.RadioButtonLatex.Size = New System.Drawing.Size(57, 17)
        Me.RadioButtonLatex.TabIndex = 0
        Me.RadioButtonLatex.TabStop = True
        Me.RadioButtonLatex.Text = "LaTeX"
        Me.RadioButtonLatex.UseVisualStyleBackColor = True
        '
        'ComboBoxTo3
        '
        Me.ComboBoxTo3.FormattingEnabled = True
        Me.ComboBoxTo3.Location = New System.Drawing.Point(191, 33)
        Me.ComboBoxTo3.Name = "ComboBoxTo3"
        Me.ComboBoxTo3.Size = New System.Drawing.Size(130, 21)
        Me.ComboBoxTo3.TabIndex = 4
        '
        'LabelTo3
        '
        Me.LabelTo3.AutoSize = True
        Me.LabelTo3.Location = New System.Drawing.Point(188, 17)
        Me.LabelTo3.Name = "LabelTo3"
        Me.LabelTo3.Size = New System.Drawing.Size(31, 13)
        Me.LabelTo3.TabIndex = 3
        Me.LabelTo3.Text = "nach"
        '
        'ComboBoxFrom3
        '
        Me.ComboBoxFrom3.FormattingEnabled = True
        Me.ComboBoxFrom3.Location = New System.Drawing.Point(15, 33)
        Me.ComboBoxFrom3.Name = "ComboBoxFrom3"
        Me.ComboBoxFrom3.Size = New System.Drawing.Size(130, 21)
        Me.ComboBoxFrom3.TabIndex = 2
        '
        'LabelFrom3
        '
        Me.LabelFrom3.AutoSize = True
        Me.LabelFrom3.Location = New System.Drawing.Point(12, 17)
        Me.LabelFrom3.Name = "LabelFrom3"
        Me.LabelFrom3.Size = New System.Drawing.Size(25, 13)
        Me.LabelFrom3.TabIndex = 1
        Me.LabelFrom3.Text = "von"
        '
        'ButtonDict
        '
        Me.ButtonDict.Location = New System.Drawing.Point(257, 118)
        Me.ButtonDict.Name = "ButtonDict"
        Me.ButtonDict.Size = New System.Drawing.Size(116, 27)
        Me.ButtonDict.TabIndex = 0
        Me.ButtonDict.Text = "Wörterbuch"
        Me.ButtonDict.UseVisualStyleBackColor = True
        '
        'FDictionary
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(420, 682)
        Me.Controls.Add(Me.GroupBoxDictionary)
        Me.Controls.Add(Me.GroupBoxWordList)
        Me.Controls.Add(Me.ButtonOK)
        Me.Controls.Add(Me.GroupBoxSingleWord)
        Me.Name = "FDictionary"
        Me.Text = "Dictionary / Export"
        Me.GroupBoxMode.ResumeLayout(False)
        Me.GroupBoxMode.PerformLayout()
        Me.GroupBoxSingleWord.ResumeLayout(False)
        Me.GroupBoxSingleWord.PerformLayout()
        Me.GroupBoxWordList.ResumeLayout(False)
        Me.GroupBoxWordList.PerformLayout()
        Me.GroupBoxOutput.ResumeLayout(False)
        Me.GroupBoxOutput.PerformLayout()
        Me.GroupBoxCriterion.ResumeLayout(False)
        Me.GroupBoxCriterion.PerformLayout()
        Me.GroupBoxDictionary.ResumeLayout(False)
        Me.GroupBoxDictionary.PerformLayout()
        Me.GroupBoxDictType.ResumeLayout(False)
        Me.GroupBoxDictType.PerformLayout()
        Me.GroupBoxFormat.ResumeLayout(False)
        Me.GroupBoxFormat.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents LabelFrom As System.Windows.Forms.Label
    Friend WithEvents ComboBoxFrom As System.Windows.Forms.ComboBox
    Friend WithEvents LabelTo As System.Windows.Forms.Label
    Friend WithEvents ComboBoxTo As System.Windows.Forms.ComboBox
    Friend WithEvents LabelWord As System.Windows.Forms.Label
    Friend WithEvents TextBoxWord As System.Windows.Forms.TextBox
    Friend WithEvents ButtonSearch As System.Windows.Forms.Button
    Friend WithEvents LabelTranslation As System.Windows.Forms.Label
    Friend WithEvents RichTextBoxTranslation As System.Windows.Forms.RichTextBox
    Friend WithEvents ButtonOK As System.Windows.Forms.Button
    Friend WithEvents GroupBoxMode As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButtonStart As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButtonStrict As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBoxSingleWord As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBoxWordList As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBoxCriterion As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButtonTheme As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButtonNiveau As System.Windows.Forms.RadioButton
    Friend WithEvents ComboBoxSortChoice As System.Windows.Forms.ComboBox
    Friend WithEvents ButtonList As System.Windows.Forms.Button
    Friend WithEvents ComboBoxTo2 As System.Windows.Forms.ComboBox
    Friend WithEvents LabelTo2 As System.Windows.Forms.Label
    Friend WithEvents ComboBoxFrom2 As System.Windows.Forms.ComboBox
    Friend WithEvents LabelFrom2 As System.Windows.Forms.Label
    Friend WithEvents GroupBoxOutput As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButtonUnicode As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButtonHtml As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBoxDictionary As System.Windows.Forms.GroupBox
    Friend WithEvents ButtonDict As System.Windows.Forms.Button
    Friend WithEvents ComboBoxFrom3 As System.Windows.Forms.ComboBox
    Friend WithEvents LabelFrom3 As System.Windows.Forms.Label
    Friend WithEvents ComboBoxTo3 As System.Windows.Forms.ComboBox
    Friend WithEvents LabelTo3 As System.Windows.Forms.Label
    Friend WithEvents GroupBoxFormat As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButtonPDF As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButtonLatex As System.Windows.Forms.RadioButton
    Friend WithEvents LabelDictionaryStatus As System.Windows.Forms.Label
    Friend WithEvents GroupBoxDictType As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButtonLexikon As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButtonDict As System.Windows.Forms.RadioButton
End Class
