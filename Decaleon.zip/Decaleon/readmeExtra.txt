Hello!

Decaleon news:
1)
- The standard Vocabulary File of Decaleon will be extended by another about 8500 words.
- The File "VokabularZusatz2.txt" contains the German Draft.
- The new words will be coded in the next 20 months.
2)
- Decaleon plus was modified to import an extra Vocabulary File containing technical terms.
- This File "VocaExtensions.xml" also is placed in the \bin\Debug\ of Decaleon.
- The technical terms including Semantic Groups will be coded in the next 16 months.
- This Vocabulary will be uploaded regularly on Sourceforge.
3)
- Group Member Indices were changed to 5 digits to reference up to 99999 words per Part of Speech.
- In the XML Vocabulary Files in the Semantic Group they are like LLLXXXXX[#LLL]; in the Program
- corresponding changes were made during import (checking, extensions) and access (dictionary window).
4)
- Design for standard Addition is completed.
- New file VocaAddition.xml is in \bin\Debug\ of Decaleon; German/English finished.
- other languages and Semantic Groups will follow, when technical Extension design is finished.
5)
- Design for technical Extension is finished.
- 20 Thematic Extensions containing about 14000 entries done (5 Languages);  
- Standard Addition was finished in spring 2016.
6)
- Version 6.0 of Decaleon software is under development. 
- A new Addition is in preparation, containing about 23500 entries; 
- about 12 additional Languages and Interslavic will be supported on A1/A2 levels. 

TEXminer news:
1) 
- TEXminer was modified to import an extra Vocabulary File containing technical terms.
- The Language Models for each language now consist of two files:
- "Vocagram.xml" for standard and "VocagramE.xml" for technical Extensions.
- Also the Semantic Group information is split into "Vocasemg.xml" and "VocasemgE.xml"

2)
- The technical term Extension is in progress till mid of 2016.
- Mathematics, Physics, Chemistry and Biology are the first samples in the Semantic Group datasets.
- Check with typical texts "Geometry.txt"/"Microscope.txt"/"Battery.txt"/"Metabolism.txt": 
- the names of the Semantic Group Hits ending with "*" are technical.

3)
- A bug in the registerSemanticGroup Routine suppressed Semantic Group Hits. 
- Now it is as it should be.

4)
- TEXminer was modified to import an additional Vocabulary File containing standard terms.
- The Language Models for each language now consist of three files:
- "Vocagram.xml" for standard, "VocagramA.xml" for addition and "VocagramE.xml" for technical Extensions.
- Also the Semantic Group information is split into "Vocasemg.xml", "VocasemgA.xml" and "VocasemgE.xml"

5)
- French, Spanish and Russian Models for Standard Vocabulary Addition have been extended.
- TEXminer now directly supports 19 Languages. Adaptions for other Languages are possible.

6)
- TEXminer will take the words of Decaleon 6.0 new Addition into the Language Models. 
- A Test Data Set is already available in German (VocaAddition2.xml->VocasemgB.xml+VocagramB.xml). 

Greetings
	M.Penzkofer

