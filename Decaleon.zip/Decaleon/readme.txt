Bedienungsanleitung und Softwaredokumentation Pentaleon 2.0 Mar 2010


Beschreibung der zulaessigen Schluesselwoerter der XML-Codierung der Grammatik

    Subjekt-Nominativ (SubNominativ)
    - Angabe des Subjekts in erster Person, Einzahl, 1. Fall bzw. als Pronomen oder Eigenname
    Preadikat-Infinitiv (PreInfinitiv)
    - Angabe des Praedikats als Verb oder als Hilfsverb
    Objekt-Nominativ (ObjNominativ)
    - Angabe des Objekts in erster Person, Einzahl, 1. Fall bzw. als Pronomen oder Eigenname
    Adjektiv (SubAdjektiv/ObjAdjektiv)
    - Angabe des Eigenschaftworts in erster Person, Einzahl
    Adverb (SubAdverb/PreAdverb/ObjAdverb)
    - Angabe des Umstandsworts in originaerer Form oder als Adjektiv (zur Ableitung) in erster Person, Einzahl
    Partizipial-Ergaenzung (SubPartizip/ObjPartizip)
    - Angabe des Verbs im Infinitiv, von dem das Partizip gebildet werden soll
    Praeposition (ObjPraeposition)
    - Angabe der Praeposition
    Duplikate / Doppelte Satzbestandteile (SubDuplikat/PreDuplikat/ObjDuplikat)
    - Angabe des Verbindungswortes vor dem zweiten bzw. folgenden Bestandteil (i.d.R. und, oder)
    Junktion (JunText)
    - Angabe des Verbindungswortes vor dem Teil-Satz (beiordnend: und; nebenordnend: nachdem, weil, etc.)
    Partikel (ParText)
    - Angabe des Partikels vor dem Teil-Satz (Antwortpartikeln: ja, nein) 
    Interpunktion / Satzzeichen (IntText)
    - Angabe des Satzzeichens nach dem Teil-Satz (./!/?/,)

    Subjekt- bzw. Objekt-Typ (SubType/ObjType)
    - Schluesselwort fuer persoenliches Fuerwort                          Pronomen
    - Schluesselwort fuer Hauptwort                                       Nomen
    - Schluesselwort fuer Eigenname                                       Name
    Genus / Geschlecht (SubGenus/ObjGenus) - fuer Esperanto nicht relevant
    - Schluesselwort fuer maennlich (maskulinum)                          m
    - Schluesselwort fuer weiblich (femininum)                            f
    - Schluesselwort fuer saechlich (neutrum)                             n
    - Schluesselwort fuer unbestimmt (Pronomen)                           0
    Numerus / Anzahl (SubNumerus/PreNumerus/ObjNumerus)
    - Zahl fuer Einzahl                                                   1
    - Zahl fuer Mehrzahl                                                  2
    Kasus / Fall (ObjKasus)
    - Zahl fuer Genitiv                                                   2
    - Zahl fuer Dativ                                                     3
    - Zahl fuer Akkusativ                                                 4
    Artikel (SubArtikel/ObjArtikel)
    - Zahl fuer ohne Artikel (Pronomen, Eigenname)                        0
    - Zahl fuer mit Artikel (Nomen)                                       1
    Person (PrePerson) - fuer Esperanto nicht relevant
    - Zahl fuer die 1. Person                                             1
    - Zahl fuer die 2. Person                                             2
    - Zahl fuer die 3. Person                                             3
    Tempus / Zeit (PreTempus)
    - Schluesselwort fuer Gegenwart                                       Praesens
    - Schluesselwort fuer Vergangenheit                                   Praeteritum
    - Schluesselwort fuer Zukunft                                         Futur
    Modus / Aussageweise (PreModus)
    - Schluesselwort fuer Wirklichkeitsform                               Indikativ
    - Schluesselwort fuer Moeglichkeitsform                               Konjunktiv
    - Schluesselwort fuer Aufforderung                                    Imperativ
    GenusVerbi / Handlungsweise (PreGenusVerbi)
    - Schluesselwort fuer Taetigkeitsform                                 Aktiv
    - Schluesselwort fuer Leideform                                       Passiv
    - Schluesselwort fuer Hilfsverb-Begleiter                             Auxiliarcomes
    Spezifische Valenz (PreSpezValenz)
    - Schluesselwort fuer ohne Objekt-Ergaenzung                          Intransitiv
    - Schluesselwort fuer mit Objekt-Ergaenzung                           Transitiv
    - Schluesselwort fuer Rueckbezug                                      Reflexiv
    - Schluesselwort fuer Hilfsverb                                       Auxiliarum
    Adjektiv-Typ (SubAdjType/ObjAdjType)
    - Schluesselwort fuer gewoehnliches Adjektiv                          Normal
    - Schluesselwort fuer Possesiv-Pronomen                               Possesiv
    Adjektiv-Form (SubAdjKomp/ObjAdjKomp)
    - Schluesselwort fuer Grundform                                       Positiv
    - Schluesselwort fuer 1. Steigerung                                   Komparativ
    - Schluesselwort fuer 2. Steigerung                                   Superlativ
    Adverb-Typ (SubAdvType/PreAdvType/ObjAdvType)
    - Schluesselwort fuer originaeres Adverb                              Original
    - Schluesselwort fuer abgeleitetes Adverb (von Adjektiv)              Derivat
    Adverb-Form (SubAdvKomp/PreAdvType/ObjAdvKomp)
    - Schluesselwort fuer Grundform                                       Positiv
    - Schluesselwort fuer 1. Steigerung                                   Komparativ
    - Schluesselwort fuer 2. Steigerung                                   Superlativ
    Partzip-Tempus / Zeit (ParTemp)
    - Schluesselwort fuer Gegenwart                                       Praesens
    - Schluesselwort fuer Vergangenheit                                   Praeteritum
    - Schluesselwort fuer Zukunft                                         Futur
    Partzip-Modus / Aussageweise (ParMod)
    - Schluesselwort fuer Wirklichkeitsform                               Indikativ
    - Schluesselwort fuer Moeglichkeitsform                               Konjunktiv (nicht implementiert)
    Partzip-GenusVerbi / Handlungsweise (ParGenV)
    - Schluesselwort fuer Taetigkeitsform                                 Aktiv
    - Schluesselwort fuer Leideform                                       Passiv
    Junktionen-Typ (JunType) - wird nicht ausgewertet
    - Schluesselwort fuer beiordnenden Bezug                              Konjunktion
    - Schluesselwort fuer unterordnenden Bezug                            Subjunktion
    Partikel-Typ (ParType) - wird nicht ausgewertet
    - Schluesselwort fuer Antwortpartikel (Entscheidungsfrage)            Decision
    - Schluesselwort fuer Ausrufewoerter                                  Interjektion
    Satzzeichen-Typ (IntType) - wird nicht ausgewertet
    - Schluesselwort fuer Aussagesetz                                     Deklarativ
    - Schluesselwort fuer Aufforderungssatz                               Imperativ
    - Schluesselwort fuer Fragessatz                                      Interrogativ
    - Schluesselwort fuer Teil-Satz                                       Partitiv


Uebersicht ueber die programmierten Grammatikalischen Endungen

    Konstanten
    Nomen
    Public Const pubEspNoArticle = ""           kein Artikel              0
    Public Const pubEspArticle = "la"           bestimmter Artikel        1
    Public Const pubEspSingular = ""            Singular - keine Zeichen  1
    Public Const pubEspPlural = "j"             Plural-Kennzeichen        2
    Kasi / Faelle
    Public Const pubEspNominative = ""          Nominativ - keine Zeichen 1
    Public Const pubEspGenitive = "de"          Genitiv-Kennzeichen       2
    Public Const pubEspDative = "al"            Dativ-Kennzeichen         3
    Public Const pubEspAccusative = "n"         Akkusativ-Kennzeichen     4
    Verben: Indikativ                                                     Indikativ
    Public Const pubEspIndPresent = "as"        Gegenwarts-Endung         Praesens
    Public Const pubEspIndPraeteritum = "is"    Imperfekt-Endung          Praeteritum
    Public Const pubEspIndFutur = "os"          FuturI-Endung             Futur
    Verben: Konjunktiv                                                    Konjunktiv
    Public Const pubEspKonPresent = "us"        Gegenwarts-Endung         Praesens
    Public Const pubEspKonPraeteritum = "us"    Imperfekt-Endung          Praeteritum
    Public Const pubEspKonFutur = "us"          FuturI-Endung             Futur
    Verben: Imperativ
    Public Const pubEspImpImperative = "u"      Imperativ-Endung          Imperativ
    Verben: Partizip Aktiv                                                Partizip
    Public Const pubEspParAktiPresent = "anta"     Gegenwarts-Endung      Praesens
    Public Const pubEspParAktiPraeteritum = "inta" Imperfekt-Endung       Praeteritum
    Public Const pubEspParAktiFutur = "onta"       FuturI-Endung          Futur
    Verben: Partizip Passiv                                               Passiv
    Public Const pubEspParPassPresent = "ata"      Gegenwarts-Endung      Praesens
    Public Const pubEspParPassPraeteritum = "ita"  Imperfekt-Endung       Praeteritum
    Public Const pubEspParPassFutur = "ota"        FuturI-Endung          Futur
    Adjektive
    Public Const pubEspAdjPositive = ""         Positiv - kein Zeichen    Positiv
    Public Const pubEspAdjKomparative = "pli"   Komparativ-Kennzeichen    Komparativ
    Public Const pubEspAdjSuperlative = "plej"  Superlativ-Kennzeichen    Superlativ
    Adverbien
    Public Const strEspAdvOriginal = ""         originaeres Adverb        Original
    Public Const strEspAdvDerivat = "e"         abgeleitetes Adverb       Derivat
    Public Const pubEspAdvPositive = ""         Positiv - kein Zeichen    Positiv
    Public Const pubEspAdvKomparative = "pli"   Komparativ-Kennzeichen    Komparativ
    Public Const pubEspAdvSuperlative = "plej"  Superlativ-Kennzeichen    Superlativ


Esperanto Uebersetzungs-Programm
Juni-Oktober 2009 Version 1.0
Maerz-Juni 2010 Version 2.0

Datenbasis Vokabular.xml ca. 7800 Woerter je Sprache
September-Dezember 2009 Version 1.0 alphabetisch Deutsch - Esperanto
Januar-Dezember 2010 Version 2.0 zusaetzlich Englisch, Franzoesisch, Spanisch, Italienisch (Pentaleon)

Markus Penzkofer
